<?php
// Include database connection
include 'db_connection.php';

// Initialize error and success messages
$error_message = "";
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $nickname = mysqli_real_escape_string($conn, $_POST['nickname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $contact_info = mysqli_real_escape_string($conn, $_POST['contact_info']); // New contact info field

    // Validate form inputs
    if (empty($fullname) || empty($nickname) || empty($email) || empty($password) || empty($contact_info)) {
        $error_message = "All fields are required.";
    } else {
        // Check if email already exists
        $check_email = "SELECT * FROM volunteers WHERE email='$email'";
        $result = $conn->query($check_email);

        if ($result->num_rows > 0) {
            $error_message = "Email is already registered.";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // Insert data into the volunteers table
            $sql = "INSERT INTO volunteers (fullname, nickname, email, password, contact_info, availability_status) 
                    VALUES ('$fullname', '$nickname', '$email', '$hashed_password', '$contact_info', 'available')";

            if ($conn->query($sql) === TRUE) {
                $success_message = "Volunteer signup successful. You can now log in.";
            } else {
                $error_message = "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Signup</title>
    <style>
        /* Same styling as the user signup page */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #fdf3f0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header .logo {
            display: flex;
            align-items: center;
        }

        header .logo img {
            width: 60px;
            margin-right: 10px;
        }

        header nav ul {
            display: flex;
            list-style: none;
        }

        header nav ul li {
            margin: 0 10px;
        }

        header nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        header nav ul li a:hover {
            color: #000;
        }

        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin-top: 20px;
        }

        .form-box {
            width: 100%;
            max-width: 500px;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.88);
        }

        .form-box h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 2rem;
            color: #ff7247;
        }

        .form-box label {
            font-size: 1.1rem;
            color: #333;
        }

        .form-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1rem;
        }

        .form-box button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-box button:hover {
            background-color: #e05c3b;
        }

        .form-box p {
            text-align: center;
            margin-top: 20px;
            font-size: 1rem;
        }

        .form-box a {
            color: #ff7247;
            text-decoration: none;
            font-weight: bold;
        }

        .form-box a:hover {
            text-decoration: underline;
        }
        footer {
        text-align: center;
        padding: 20px 0;
        background: linear-gradient(90deg, #ff6e40, #ffa726);
        color: #fff;
        margin-top: 20px;
        font-size: 14px;
    }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="assets/logo1.png" alt="UniBite Logo">
            <h1>UniBite</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="donate.php">Donate</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="aboutus.php">About Us</a></li>
                <li><a href="login.php" class="login">Login</a></li>
            </ul>
        </nav>
    </header>

    <div class="form-container">
        <div class="form-box">
            <h2>Volunteer Signup</h2>
            <?php if (!empty($error_message)): ?>
                <div style="color: red; text-align: center; margin-bottom: 10px;">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($success_message)): ?>
                <div style="color: green; text-align: center; margin-bottom: 10px;">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            <form method="POST">
                <label for="fullname">Full Name:</label>
                <input type="text" id="fullname" name="fullname" required>

                <label for="nickname">Nickname:</label>
                <input type="text" id="nickname" name="nickname" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <label for="contact_info">Contact Info:</label>
                <input type="text" id="contact_info" name="contact_info" required>

                <button type="submit">Sign Up</button>
            </form>
            <!-- New Volunteer Login Button -->
        <p>Already a volunteer? <a href="volunteerlogin.php">Log in here</a></p>
    </div>
</div>
        </div>
    </div>
    <footer>
        <p>&copy; 2025 UniBite. All Rights Reserved.</p>
    </footer>
</body>
</html>
