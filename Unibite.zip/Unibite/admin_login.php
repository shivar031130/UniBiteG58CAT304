<?php
session_start();
require 'db_connection.php'; // Make sure you include your DB connection file

// Check if the form was submitted
if (isset($_POST['admin_email']) && isset($_POST['admin_password'])) {
    $admin_email = $_POST['admin_email'];
    $admin_password = $_POST['admin_password']; // Entered password

    // Prepare the query to fetch the admin data
    $sql = "SELECT admin_id, admin_password, role FROM admin WHERE admin_email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admin_email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if an admin with this email exists
    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();

        // Verify the entered password against the stored plain password
        if ($admin_password === $admin['admin_password']) {
            // Password is correct
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['role'] = $admin['role'];

            // Redirect to the admin verification page
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error_message = "Incorrect password.";
        }
    } else {
        $error_message = "No admin found with this email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - UniBite</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* Basic Styling */
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(to right, #6a11cb, #2575fc);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }

        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            transition: transform 0.3s ease-in-out;
        }

        .login-container:hover {
            transform: translateY(-10px);
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-size: 16px;
            font-weight: 500;
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 16px;
            transition: border 0.3s ease;
        }

        .form-group input:focus {
            border-color: #2575fc;
            outline: none;
        }

        .form-group button {
            width: 100%;
            padding: 15px;
            background-color: #2575fc;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-group button:hover {
            background-color: #6a11cb;
        }

        .error-message {
            color: #f44336;
            text-align: center;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #fff;
        }

        .footer p {
            margin: 0;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>Admin Login</h2>

        <?php
        // Display error message if login fails
        if (isset($error_message)) {
            echo '<div class="error-message">' . $error_message . '</div>';
        }
        ?>

        <!-- Admin login form -->
        <form action="admin_login.php" method="POST">
            <div class="form-group">
                <label for="admin_email">Email</label>
                <input type="email" id="admin_email" name="admin_email" required>
            </div>
            <div class="form-group">
                <label for="admin_password">Password</label>
                <input type="password" id="admin_password" name="admin_password" required>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
    </div>

    <footer class="footer">
        <p>&copy; 2025 UniBite. All Rights Reserved.</p>
    </footer>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
