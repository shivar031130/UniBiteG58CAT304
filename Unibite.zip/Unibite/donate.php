<?php
// Include database connection
include('db_connection.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Handle the donation form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['donate'])) {
    // Get user ID from session
    $user_id = $_SESSION['id'];

    // Sanitize and validate form input
    $meal_name = mysqli_real_escape_string($conn, $_POST['mealName']);
    $meal_description = mysqli_real_escape_string($conn, $_POST['mealDescription']);
    $meal_quantity = (int)$_POST['mealQuantity'];
    $nutritional_content = mysqli_real_escape_string($conn, $_POST['mealNutritionalContent']);
    $pickup_delivery = $_POST['pickupDelivery'];
    $food_bank_location = $_POST['foodBankLocation'];
    $contact_info = mysqli_real_escape_string($conn, $_POST['contactInfo']);
    $expiry_date = mysqli_real_escape_string($conn, $_POST['expiryDate']);

    // Handle file upload
    if (isset($_FILES['mealImage'])) {
        $file_name = $_FILES['mealImage']['name'];
        $file_tmp = $_FILES['mealImage']['tmp_name'];
        $file_error = $_FILES['mealImage']['error'];

        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($file_ext, $allowed_ext) && $file_error === 0) {
            // Define the folder where the image will be stored
            $upload_dir = 'meal_images/';
            $file_new_name = uniqid() . '.' . $file_ext;
            $file_destination = $upload_dir . $file_new_name;

            // Move the uploaded file to the designated folder
            if (move_uploaded_file($file_tmp, $file_destination)) {
                // Insert the donation data into the database with the image path
                $donation_query = "
                    INSERT INTO donations (
                        id, meal_name, meal_description, meal_image, meal_quantity, 
                        initial_quantity, nutritional_content, pickup_delivery, 
                        food_bank_location, contact_info, donation_date, expiry_date
                    ) 
                    VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?
                    )";

                $stmt = $conn->prepare($donation_query);
                $stmt->bind_param(
                    'isssiisssss',
                    $user_id, $meal_name, $meal_description, $file_new_name, 
                    $meal_quantity, $meal_quantity, $nutritional_content, 
                    $pickup_delivery, $food_bank_location, $contact_info, $expiry_date
                );

                if ($stmt->execute()) {
                    echo "Donation successful!";
                } else {
                    echo "Error: " . $stmt->error;
                }
            } else {
                echo "Error uploading the file.";
            }
        } else {
            echo "Invalid file type or upload error.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate Food | UniBite</title>
    <link rel="stylesheet" href="donate.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">
            <img src="assets/logo1.png" alt="UniBite Logo">
            <h1>UniBite</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php" class="nav-link">Home</a></li>
                <li><a href="donate.php" class="nav-link">Donate</a></li>
                <li><a href="services.html" class="nav-link">Services</a></li>
                <li><a href="contact.html" class="nav-link">Contact</a></li>
                <li><a href="aboutus.html" class="nav-link">About Us</a></li>
                <li><a href="logout.php" class="nav-link login">Logout</a></li>
            </ul>
        </nav>
    </header>

    <!-- Donate Section -->
    <section class="donate-section">
        <h2>Donate a Food</h2>
        <div class="donate-form-container">
            <form id="donateForm" action="donate.php" method="POST" enctype="multipart/form-data" class="donate-form">
                <div class="form-group">
                    <label for="mealName">Food Name:</label>
                    <input type="text" id="mealName" name="mealName" required placeholder="Enter the name of the meal">
                </div>

                <div class="form-group">
                    <label for="mealDescription">Food Description:</label>
                    <textarea id="mealDescription" name="mealDescription" rows="4" required placeholder="Describe the meal"></textarea>
                </div>

                <div class="form-group">
                    <label for="mealImage">Upload Food Image:</label>
                    <input type="file" id="mealImage" name="mealImage" accept="image/*" required>
                </div>

                <div class="form-group">
                    <label for="mealQuantity">Quantity Available:</label>
                    <input type="number" id="mealQuantity" name="mealQuantity" required min="1" placeholder="Enter the quantity of meals available">
                </div>

                <div class="form-group">
                    <label for="mealNutritionalContent">Nutritional Content:</label>
                    <textarea id="mealNutritionalContent" name="mealNutritionalContent" rows="4" placeholder="Enter nutritional content (e.g., calories, ingredients)"></textarea>
                </div>

                <div class="form-group">
                    <label for="pickupDelivery">Available For:</label>
                    <select id="pickupDelivery" name="pickupDelivery" required>
                        <option value="">Select an option</option>
                        <option value="pickup">Pick-Up</option>
                        <option value="delivery">Delivery</option>
                        <option value="both">Both</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="foodBankLocation">Food Bank Location:</label>
                    <select id="foodBankLocation" name="foodBankLocation" required>
                        <option value="">Select a location</option>
                        <option value="IK cafe L05">IK cafe L05</option>
                        <option value="IK cafe L10">IK cafe L10</option>
                        <option value="Restu Cafe">Restu Cafe</option>
                        <option value="Tekun Cafe">Tekun Cafe</option>
                        <option value="Aman Cafe">Aman Cafe</option>
                        <option value="Foodbank USM">Foodbank USM</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="expiryDate">Expiry Date:</label>
                    <input type="date" id="expiryDate" name="expiryDate" required>
                </div>

                <div class="form-group">
                    <label for="contactInfo">Your Contact Info:</label>
                    <input type="text" id="contactInfo" name="contactInfo" required placeholder="Your contact info (e.g., phone or email)">
                </div>

                <button type="submit" name="donate" class="submit-btn">Submit Donation</button>
            </form>
        </div>
    </section>

    <footer>
        <p>© 2025 UniBite. All rights reserved. | Campus Food Bank Initiative</p>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
