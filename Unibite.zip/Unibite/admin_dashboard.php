<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unibite"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total users
$sql_users = "SELECT COUNT(*) AS total_users FROM users";
$result_users = $conn->query($sql_users);
$total_users = $result_users->fetch_assoc()['total_users'];

// Fetch total volunteers
$sql_volunteers = "SELECT COUNT(*) AS total_volunteers FROM volunteers";
$result_volunteers = $conn->query($sql_volunteers);
$total_volunteers = $result_volunteers->fetch_assoc()['total_volunteers'];

// Fetch total donations
$sql_donations = "SELECT COUNT(*) AS total_donations FROM donations";
$result_donations = $conn->query($sql_donations);
$total_donations = $result_donations->fetch_assoc()['total_donations'];

// Fetch total reservations
$sql_reservations = "SELECT COUNT(*) AS total_reservations FROM reservations";
$result_reservations = $conn->query($sql_reservations);
$total_reservations = $result_reservations->fetch_assoc()['total_reservations'];

// Fetch total feedback
$sql_feedback = "SELECT COUNT(*) AS total_feedback FROM feedback";
$result_feedback = $conn->query($sql_feedback);
$total_feedback = $result_feedback->fetch_assoc()['total_feedback'];

// Fetch reservations count grouped by months
$reservations_query = "SELECT MONTH(reservation_date) AS month, COUNT(*) AS count FROM reservations GROUP BY MONTH(reservation_date)";
$reservations_result = $conn->query($reservations_query);
$reservations_data = array_fill(1, 12, 0); // Initialize array for all months
while ($row = $reservations_result->fetch_assoc()) {
    $reservations_data[intval($row['month'])] = intval($row['count']);
}

// Fetch donations count grouped by months
$donations_query = "SELECT MONTH(donation_date) AS month, COUNT(*) AS count FROM donations GROUP BY MONTH(donation_date)";
$donations_result = $conn->query($donations_query);
$donations_data = array_fill(1, 12, 0); // Initialize array for all months
while ($row = $donations_result->fetch_assoc()) {
    $donations_data[intval($row['month'])] = intval($row['count']);
}

// Fetch user registrations count grouped by months
$users_query = "SELECT MONTH(created_at) AS month, COUNT(*) AS count FROM users GROUP BY MONTH(created_at)";
$users_result = $conn->query($users_query);
$users_data = array_fill(1, 12, 0); // Initialize array for all months
while ($row = $users_result->fetch_assoc()) {
    $users_data[intval($row['month'])] = intval($row['count']);
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="icon" href="assets/logo1.png">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f4f7fc;
      color: #333;
    }
    header {
      background-color: #007bff;
      color: white;
      padding: 15px;
      text-align: center;
    }
    header h1 {
      margin: 0;
    }
    nav ul {
      list-style: none;
      padding: 0;
      text-align: center;
    }
    nav ul li {
      display: inline;
      margin: 0 15px;
    }
    nav ul li a {
      color: white;
      text-decoration: none;
      font-weight: bold;
    }
    nav ul li a:hover {
      text-decoration: underline;
    }
    main {
      padding: 20px;
    }
    .statistics {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
      margin-bottom: 30px;
      transition: box-shadow 0.3s ease-in-out;
      transform: translateY(-10px);
    }
    .stat-card {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.9);
      text-align: center;
      transition: box-shadow 0.3s ease-in-out;
    }
    .stat-card h3 {
      margin: 0;
      font-size: 20px;
      color: #007bff;
    }
    /* Table Styling */
.table {
  width: 100%;
  margin-bottom: 1rem;
  background-color: #fff;
  border-collapse: collapse;
}

/* Table Headers Styling */
.table th {
  padding: 12px 15px;
  text-align: left;
  background-color: #f8f9fa;
  color: #495057;
  font-weight: bold;
  border-bottom: 2px solid #dee2e6;
}

/* Table Data Cells Styling */
.table td {
  padding: 12px 15px;
  border-bottom: 1px solid #dee2e6;
  vertical-align: middle;
  color: #212529;
}

/* Zebra Stripes (Alternating Row Colors) */
.table tbody tr:nth-child(odd) {
  background-color: #f9f9f9;
}

/* Hover Effect for Rows */
.table tbody tr:hover {
  background-color: #e9ecef;
  cursor: pointer;
}

/* Table Border Styling */
.table-bordered {
  border: 1px solid #dee2e6;
}

.table-bordered th, .table-bordered td {
  border: 1px solid #dee2e6;
}

/* Table Responsive Styling (For Mobile View) */
@media (max-width: 768px) {
  .table {
    font-size: 12px;
  }

  .table th, .table td {
    padding: 8px 10px;
  }
}
    .stat-card p {
      font-size: 24px;
      font-weight: bold;
    }
    .charts-container {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      flex-wrap: wrap;
    }
    .chart-container {
      width: 100%;
      max-width: 500px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.9);
      border-radius: 10px;
      background-color: #fff;
      padding: 20px;
      margin-bottom: 30px;
      transition: box-shadow 0.3s ease-in-out;
    }
    .chart-container:hover {
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }
    canvas {
      max-width: 100%;
      max-height: 250px;
    }
    footer {
      text-align: center;
      padding: 10px;
      background-color: #007bff;
      color: white;
      margin-top: 40px;
    }
    footer p {
      margin: 0;
    }
  </style>
</head>
<body>
  <header>
    <h1>Welcome to Admin Dashboard</h1>
    <nav>
      <ul>
        <li><a href="admin_dashboard.php">Dashboard</a></li>
        <li><a href="verify_users.php">Verify Users</a></li>
        <li><a href="verify_volunteer.php">Verify Volunteers</a></li>
        <li><a href="activity_portal.php">Activity Portal</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="statistics">
      <h2>Overall Statistics</h2>
      <div class="stat-card">
        <h3>Total Users</h3>
        <p><?php echo $total_users; ?></p>
      </div>
      <div class="stat-card">
        <h3>Total Volunteers</h3>
        <p><?php echo $total_volunteers; ?></p>
      </div>
      <div class="stat-card">
        <h3>Total Donations</h3>
        <p><?php echo $total_donations; ?></p>
      </div>
      <div class="stat-card">
        <h3>Total Reservations</h3>
        <p><?php echo $total_reservations; ?></p>
      </div>
      <div class="stat-card">
        <h3>Total Feedback</h3>
        <p><?php echo $total_feedback; ?></p>
      </div>
    </section>

    <section class="charts-container">
      <div class="chart-container">
        <canvas id="reservationsChart"></canvas>
      </div>
      <div class="chart-container">
        <canvas id="donationsChart"></canvas>
      </div>
      <div class="chart-container">
        <canvas id="userChart"></canvas>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 UniBite Food Bank System</p>
  </footer>

  <script>
    // PHP data to JavaScript
    const reservationsData = <?php echo json_encode(array_values($reservations_data)); ?>;
    const donationsData = <?php echo json_encode(array_values($donations_data)); ?>;
    const usersData = <?php echo json_encode(array_values($users_data)); ?>;
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    // Chart for Reservations
    const reservationsChartCtx = document.getElementById("reservationsChart").getContext("2d");
    new Chart(reservationsChartCtx, {
      type: "bar",
      data: {
        labels: months,
        datasets: [{
          label: "Reservations",
          data: reservationsData,
          borderColor: "rgb(13, 10, 169)",
          backgroundColor: "rgba(255, 114, 71, 0.2)",
          borderWidth: 2,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: { beginAtZero: true }
        }
      }
    });

    // Chart for Donations
    const donationsChartCtx = document.getElementById("donationsChart").getContext("2d");
    new Chart(donationsChartCtx, {
      type: "line",
      data: {
        labels: months,
        datasets: [{
          label: "Donations",
          data: donationsData,
          borderColor: "rgba(71, 223, 255, 1)",
          backgroundColor: "rgba(71, 223, 255, 0.2)",
          borderWidth: 2,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: { beginAtZero: true }
        }
      }
    });

    // Chart for User Registrations
    const userChartCtx = document.getElementById("userChart").getContext("2d");
    new Chart(userChartCtx, {
      type: "pie",
      data: {
        labels: months,
        datasets: [{
          label: "Users",
          data: usersData,
          borderColor: "rgb(204, 78, 28)",
          backgroundColor: "rgba(255, 85, 0, 0.77)",
          borderWidth: 2,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  </script>
</body>
</html>
