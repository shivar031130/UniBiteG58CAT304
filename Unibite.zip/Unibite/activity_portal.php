<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unibite"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql_donations = "
    SELECT 
        d.donation_id, 
        d.meal_name, 
        d.id, 
        u.fullname,
        d.initial_quantity,
        d.donation_date,
        d.expiry_date
    FROM donations d
    INNER JOIN users u ON d.id = u.id
    ORDER BY d.donation_id ASC
";
$result_donations = $conn->query($sql_donations);

// Fetch all reservations
$sql_reservations = "
    SELECT 
        r.reservation_id, 
        r.id, 
        r.donation_id,
        u.fullname,
        r.reservation_date,
        r.method_of_delivery,
        r.pickup_deadline
    FROM reservations r
    INNER JOIN users u ON r.id = u.id
    ORDER BY r.reservation_id ASC
";
$result_reservations = $conn->query($sql_reservations);

// Fetch all feedback
$sql_feedback = "
    SELECT 
        f.feedback_id, 
        f.reservation_id, 
        u_feedback.fullname AS feedback_user_fullname, -- Full name of the user who left feedback
        d.donation_id, 
        u_donor.fullname AS donor_fullname, -- Full name of the user who donated food
        f.rating,
        f.comments,
        f.feedback_date
    FROM feedback f
    INNER JOIN reservations r ON f.reservation_id = r.reservation_id
    INNER JOIN donations d ON r.donation_id = d.donation_id
    INNER JOIN users u_feedback ON f.id = u_feedback.id -- Feedback user
    INNER JOIN users u_donor ON d.id = u_donor.id -- Donor user
    ORDER BY f.feedback_date ASC
";
$result_feedback = $conn->query($sql_feedback);


// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Activity Portal</title>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f9f9f9;
      margin: 0;
      padding: 0;
      height: 100vh;
    }

    header {
      background: #4c6ef5;
      color: #fff;
      padding: 20px;
      text-align: center;
    }

    header h1 {
      margin: 0;
      font-size: 2.5rem;
      font-weight: 600;
    }

    nav ul {
      list-style: none;
      padding: 0;
      margin: 10px 0 0;
    }

    nav ul li {
      display: inline;
      margin: 0 20px;
    }

    nav ul li a {
      color: #fff;
      text-decoration: none;
      font-weight: 500;
      font-size: 1.2rem;
      transition: color 0.3s ease;
    }

    nav ul li a:hover {
      color: #ffd700;
    }

    main {
      width: 80%;
      max-width: 1200px;
      margin: 30px auto;
    }

    .table {
      width: 100%;
      margin-bottom: 30px;
      border-collapse: collapse;
    }

    .table th, .table td {
      padding: 12px 15px;
      text-align: left;
      border: 1px solid #ddd;
      font-size: 1rem;
    }

    .table thead {
      background: linear-gradient(90deg, #4c6ef5, #ff6e7f);
      color: #fff;
    }

    .table tbody tr:nth-child(odd) {
      background-color: #f3f3f3;
    }

    .table tbody tr:nth-child(even) {
      background-color: #ffffff;
    }

    .table tbody tr:hover {
      background-color: #f0f0f0;
    }

    footer {
      background: #222;
      color: #fff;
      text-align: center;
      padding: 15px;
      font-size: 1rem;
    }

    footer a {
      color: #ffd700;
      text-decoration: none;
    }
  </style>
</head>
<body>

<header>
  <h1>Activity Portal</h1>
  <nav>
    <ul>
      <li><a href="admin_dashboard.php">Dashboard</a></li>
      <li><a href="activity_portal.php">Activity Portal</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>
</header>

<main>
  <div class="card-wrapper">

    <!-- Donations Table -->
    <div class="card">
      <div class="card-title">Donations</div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Donation ID</th>
            <th>Donor ID</th>
            <th>Donor Name</th>
            <th>Meal Name</th>
            <th>Meal Quantity</th>
            <th>Donation Date</th>
            <th>Expiry Date</th>

          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result_donations->fetch_assoc()): ?>
            <tr>
              <td><?php echo $row['donation_id']; ?></td>
              <td><?php echo $row['id']; ?></td>
              <td><?php echo $row['fullname']; ?></td>
              <td><?php echo $row['meal_name']; ?></td>
              <td><?php echo $row['initial_quantity']; ?></td>
              <td><?php echo $row['donation_date']; ?></td>
              <td><?php echo $row['expiry_date']; ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <!-- Reservations Table -->
    <div class="card">
      <div class="card-title">Reservations</div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Reservation ID</th>
            <th>Donation ID</th>
            <th>Recipient ID</th>
            <th>Recipient Name</th>
            <th>Reservation Date</th>
            <th>Delivery Method</th>
            <th>Pickup Deadline</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result_reservations->fetch_assoc()): ?>
            <tr>
              <td><?php echo $row['reservation_id']; ?></td>
              <td><?php echo $row['donation_id']; ?></td>
              <td><?php echo $row['id']; ?></td>
              <td><?php echo $row['fullname']; ?></td>
              <td><?php echo $row['reservation_date']; ?></td>
              <td><?php echo $row['method_of_delivery']; ?></td>
              <td><?php echo $row['pickup_deadline']; ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <!-- Feedback Table -->
    <div class="card">
      <div class="card-title">Feedback</div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Feedback ID</th>
            <th>Reservation ID</th>
            <th>User Name</th>
            <th>Donation ID</th>
            <th>Donor Name</th>
            <th>Rating</th>
            <th>Comment</th>
            <th>Feedback Date</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($row = $result_feedback->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['feedback_id']; ?></td>
        <td><?php echo $row['reservation_id']; ?></td>
        <td><?php echo $row['feedback_user_fullname']; ?></td>
        <td><?php echo $row['donation_id']; ?></td>
        <td><?php echo $row['donor_fullname']; ?></td>
        <td><?php echo $row['rating']; ?></td>
        <td><?php echo $row['comments']; ?></td>
        <td><?php echo $row['feedback_date']; ?></td>
    </tr>
<?php endwhile; ?>

        </tbody>
      </table>
    </div>
  </div>

  <a href="admin_dashboard.php" class="btn btn-primary">Back to Dashboard</a>
</main>

<footer>
  &copy; 2025 Unibite. All rights reserved.
</footer>

</body>
</html>
