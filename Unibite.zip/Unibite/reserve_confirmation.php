<?php
session_start();
include('db_connection.php');

// Get logged-in user ID
$id = $_SESSION['id'];

// Get reservation ID from URL
$reservation_id = $_GET['reservation_id'] ?? null;

if ($reservation_id) {
    // Fetch reservation details
    $query = "SELECT * FROM reservations WHERE reservation_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $reservation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $reservation = $result->fetch_assoc();

    // Fetch donation details
    $donation_query = "SELECT * FROM donations WHERE donation_id = ?";
    $donation_stmt = $conn->prepare($donation_query);
    $donation_stmt->bind_param("i", $reservation['donation_id']);
    $donation_stmt->execute();
    $donation_result = $donation_stmt->get_result();
    $donation = $donation_result->fetch_assoc();

    // Prepare the data for the QR code (Reservation ID and Meal Info)
    $qr_data = "Reservation ID: " . $reservation_id . "\n" .
               "Meal: " . $donation['meal_name'] . "\n" .
               "Date: " . $reservation['reservation_date'] . "\n" .
               "Address: " . $reservation['delivery_address'] . "\n" .
               "Status: " . ucfirst($reservation['status']);

    // Generate the QR Code URL using the API
    $qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode($qr_data);
} else {
    // Redirect if reservation ID is missing
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation QR Code</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: #f1f1f1;
            color: #333;
        }

        header {
            background: linear-gradient(90deg, #ff6e40, #ffa726);
            color: white;
            padding: 20px 40px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        header h1 {
            margin: 0;
            font-size: 32px;
            letter-spacing: 1px;
        }

        main {
            max-width: 700px;
            margin: 30px auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .qr-container {
            text-align: center;
            margin-bottom: 0%;
        }

        .qr-container h2 {
            color: #FF5722;
            font-size: 26px;
            margin-bottom: 5px;
            margin-top: 2px;
            font-weight: 400;
            font-weight: bold;
            text-transform: uppercase;
        }

        .qr-container p {
            margin: 10px 0;
            font-size: 18px;
            line-height: 1.6;
        }

        .qr-container h3 {
            margin-top: 15px;
            font-size: 22px;
            color: #333;
            font-weight: 500;
        }

        .qr-code {
            display: block;
            margin: 20px auto;
            border: 3px solid #ddd;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .home-button {
            margin-top: 3px;
            padding: 10px 10px;
            background-color: #FF5722;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .home-button:hover {
            background-color: #FF7043;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: linear-gradient(90deg, #ff6e40, #ffa726);
            color: white;
            position: fixed;
            bottom: 0;
            margin-top: 50px;
            width: 100%;
            box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.2);
            font-size: 14px;
        }

        footer p {
            margin: 0;
        }

        /* Hover effect for QR */
        .qr-code:hover {
            transform: scale(1.05);
            transition: all 0.3s ease;
        }

        /* Responsive Styles */
        @media (max-width: 600px) {
            main {
                margin: 20px;
                padding: 20px;
            }

            header h1 {
                font-size: 26px;
            }

            .qr-container h2 {
                font-size: 24px;
            }

            .qr-container h3 {
                font-size: 20px;
            }

            .qr-container p {
                font-size: 16px;
            }

            .home-button {
                font-size: 16px;
                padding: 10px 16px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Reservation QR Code</h1>
    </header>
    <main>
        <div class="qr-container">
            <h2>Your Reservation Details</h2>
            <p><strong>Meal Name:</strong> <?= htmlspecialchars($donation['meal_name']) ?></p>
            <p><strong>Reservation Date:</strong> <?= htmlspecialchars($reservation['reservation_date']) ?></p>
            <p><strong>Delivery Address:</strong> <?= htmlspecialchars($reservation['delivery_address']) ?></p>
            <p><strong>Method of Delivery:</strong> <?= htmlspecialchars(ucfirst($reservation['method_of_delivery'])) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($reservation['status']) ?></p>
            <p><strong>Deadline:</strong> <?= htmlspecialchars($reservation['pickup_deadline']) ?></p>

            <h3>Save the QR Code below for verification:</h3>
            <img src="<?= $qr_code_url ?>" alt="QR Code" class="qr-code">

            <!-- Home Button -->
            <a href="index.php">
                <button class="home-button">Back to Home</button>
            </a>
        </div>
    </main>
    <footer>
        <p>&copy; 2025 UniBite. All rights reserved.</p>
    </footer>
</body>
</html>
