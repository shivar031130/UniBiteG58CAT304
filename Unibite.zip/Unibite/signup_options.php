<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Options - UniBite</title>
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Body */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #fdf3f0;
        }
        
        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        header .logo {
            display: flex;
            align-items: center;
        }
        
        header .logo img {
            width: 60px;
            margin-right: 10px;
        }
        
        header nav ul {
            display: flex;
            list-style: none;
        }
        
        header nav ul li {
            margin: 0 10px;
        }
        
        header nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }
        
        header nav ul li a:hover {
            color: #000;
        }
        
        header nav ul li .login {
            background-color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
        }
        
        /* Form Container */
        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin-top: 50px;
        }
        
        .form-box {
            width: 100%;
            max-width: 500px;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        
        .form-box h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 2rem;
            color: #ff7247;
        }
        
        .signup-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            text-align: center;
            margin: 10px 0;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .signup-btn:hover {
            background-color: #e05c3b;
        }
        
        /* Footer */
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 1rem;
            color: #555;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="assets/logo1.png" alt="UniBite Logo">
            <h1>UniBite</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="donate.php">Donate</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="contactus.html">Contact</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="login.php" class="login">Login</a></li>
            </ul>
        </nav>
    </header>

    <!-- Signup Options -->
    <div class="form-container">
        <div class="form-box">
            <h2>Choose Signup Option</h2>
            <a href="signup.php" class="signup-btn">Sign Up as User</a>
            <a href="signup_volunteer.php" class="signup-btn">Sign Up as Volunteer</a>
            <!-- Admin Login Button -->
            <a href="admin_login.php" class="signup-btn">Admin Login</a> <!-- Redirect to Admin Login -->
        </div>
    </div>

    <footer>
        <p>&copy; 2025 UniBite. All Rights Reserved.</p>
    </footer>
</body>
</html>
