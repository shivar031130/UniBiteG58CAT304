<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unibite"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start the session to track the logged-in user
session_start();

// Assume the user is logged in and we are fetching their donation history using the user ID from the session
$id = $_SESSION['id']; // Make sure this value is set during login (e.g., $_SESSION['user_id'] = $user_id);

// Fetch the donation history for the logged-in user from the 'donations' table
$sql = "SELECT donation_id, meal_name, meal_description, initial_quantity, pickup_delivery, food_bank_location, donation_date FROM donations WHERE id = $id ORDER BY donation_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UniBite - Donation History</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body, h1, h2, h3, p, ul, li, a, input, select, button, textarea, table {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    body {
        background-color: #fef9f4;
        color: #333;
        line-height: 1.6;
        font-size: 16px;
    }

    /* Navbar Styling */
    nav.navbar {
        background: linear-gradient(90deg, #ff6e40, #ffa726);
        color: #fff;
        padding: 10px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
    }

    nav.navbar .navbar-brand {
        font-size: 24px;
        font-weight: 700;
        color: #fff;
        text-decoration: none;
    }

    nav.navbar .nav-link {
        color: #fff;
        text-decoration: none;
        font-size: 16px;
        padding: 8px 12px;
        border-radius: 4px;
        transition: background 0.3s ease, color 0.3s ease;
    }

    nav.navbar .nav-link:hover {
        background-color: #fff;
        color: #ff6e40;
    }

    /* Container and Card Styling */
    .container {
        max-width: 900px;
        margin: 30px auto;
        padding: 20px;
        background: linear-gradient(145deg, #ffffff, #f3f3f3);
        box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .container:hover {
        transform: translateY(-5px);
        box-shadow: 0px 12px 30px rgba(0, 0, 0, 0.2);
    }

    .feedback-title {
        font-size: 22px;
        font-weight: 600;
        margin-bottom: 20px;
        color: #ff6e40;
    }

    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        border-radius: 8px;
    }

    table th, table td {
        padding: 12px 15px;
        text-align: left;
        border: 1px solid #ddd;
        font-size: 16px;
        font-weight: bold;
        color: #333;
        background-color: #fff;
        transition: background-color 0.3s ease;
    }

    table th {
        background: linear-gradient(90deg, #ff6e40, #ffa726);
        color: #fff;
        font-weight: 600;
    }

    table tr:nth-child(even) td {
        background-color: #f9f9f9;
    }

    table tr:hover td {
        background-color: #ffe5d4;
    }

    /* Button Styling */
    .home-button {
        margin-top: 20px;
        padding: 12px 20px;
        background: linear-gradient(90deg, #ff6e40, #ffa726);
        color: #fff;
        border: none;
        border-radius: 4px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
    }

    .home-button:hover {
        background: linear-gradient(90deg, #ff5722, #ff9800);
        transform: translateY(-2px);
        box-shadow: 0px 8px 20px rgba(255, 110, 64, 0.5);
    }

    /* Footer Styling */
    footer {
        text-align: center;
        padding: 20px 0;
        background: linear-gradient(90deg, #ff6e40, #ffa726);
        color: #fff;
        margin-top: 30px;
        font-size: 14px;
    }
</style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">UniBite</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ml-auto">
        <li><a href="index.php" class="nav-link">Home</a></li>
        <li><a href="donate.php" class="nav-link">Donate</a></li>
        <li><a href="services.php" class="nav-link">Services</a></li>
        <li><a href="contact.php" class="nav-link">Contact</a></li>
        <li><a href="aboutus.php" class="nav-link">About Us</a></li>
        <li><a href="logout.php" class="nav-link login">Logout</a></li>
      </ul>
    </div>
  </nav>

  <div class="container">
    <h2 class="feedback-title">Your Donation History</h2>
    <div class="card">
      <div class="card-body">
        <p>Here are your past donations.</p>
        <!-- Donation History Table -->
        <table class="table table-bordered table-striped table-responsive">
          <thead>
            <tr>
              <th>#</th>
              <th>Donation ID</th>
              <th>Meal Name</th>
              <th>Meal Description</th>
              <th>Quantity</th>
              <th>Pickup/Delivery</th>
              <th>Location</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php
            if ($result->num_rows > 0) {
              $index = 1;
              // Loop through the donations and display them
              while ($row = $result->fetch_assoc()) {
                echo '<tr>
                        <td>' . $index++ . '</td>
                        <td>' . htmlspecialchars($row['donation_id']) . '</td>
                        <td>' . htmlspecialchars($row['meal_name']) . '</td>
                        <td>' . htmlspecialchars($row['meal_description']) . '</td>
                        <td>' . htmlspecialchars($row['initial_quantity']) . '</td>
                        <td>' . htmlspecialchars($row['pickup_delivery']) . '</td>
                        <td>' . htmlspecialchars($row['food_bank_location']) . '</td>
                        <td>' . date("d-m-Y", strtotime($row['donation_date'])) . '</td>
                      </tr>';
              }
            } else {
              echo "<tr><td colspan='8'>No donations found.</td></tr>";
            }
            ?>
          </tbody>
        </table>
        <a href="index.php">
                <button class="home-button">Back to Home</button>
            </a>
      </div>
    </div>
  </div>

  <footer class="text-center mt-4">
    <p>&copy; 2025 UniBite - All Rights Reserved</p>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
