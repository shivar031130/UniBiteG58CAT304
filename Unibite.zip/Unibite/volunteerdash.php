<?php
session_start();

if (!isset($_SESSION['volunteer_id'])) {
    // Redirect to login if the session is not set
    header("Location: volunteerlogin.php");
    exit();
}
include('db_connection.php');

// Fetch logged-in volunteer's details
$volunteer_id = $_SESSION['volunteer_id'];
$query = "SELECT fullname, email, availability_status FROM volunteers WHERE volunteer_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$result = $stmt->get_result();
$volunteer = $result->fetch_assoc();

$delivery_query = "SELECT r.reservation_id, u.nickname AS nickname, d.meal_name, r.status, r.pickup_deadline, d.food_bank_location, r.drop_point, r.pickup_deadline
                   FROM reservations r
                   JOIN users u ON r.id = u.id
                   JOIN donations d ON r.donation_id = d.donation_id
                   WHERE r.volunteer_id = ?";
$stmt = $conn->prepare($delivery_query);
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$deliveries = $stmt->get_result();

// Fetch delivery data for the chart
$chart_query = "
    SELECT 
        SUM(CASE WHEN status = 'completed' AND method_of_delivery = 'delivery' THEN 1 ELSE 0 END) AS completed_deliveries,
        SUM(CASE WHEN status = 'pending' AND method_of_delivery = 'delivery' THEN 1 ELSE 0 END) AS pending_deliveries
    FROM reservations 
    WHERE volunteer_id = ?";
$stmt = $conn->prepare($chart_query);
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$chart_result = $stmt->get_result()->fetch_assoc();
$completed_deliveries = $chart_result['completed_deliveries'] ?? 0;
$pending_deliveries = $chart_result['pending_deliveries'] ?? 0;

// Handle "Mark as Completed" request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reservation_id'])) {
    $reservation_id = $_POST['reservation_id'];
    $update_query = "UPDATE reservations SET status = 'completed' WHERE reservation_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("i", $reservation_id);
    if ($update_stmt->execute()) {
        echo "<script>alert('Marked as completed');</script>";
    } else {
        echo "<script>alert('Error updating status');</script>";
    }
}

// Handle availability update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['availability_status'])) {
    $availability_status = $_POST['availability_status'];
    $update_availability_query = "UPDATE volunteers SET availability_status = ? WHERE volunteer_id = ?";
    $availability_stmt = $conn->prepare($update_availability_query);
    $availability_stmt->bind_param("si", $availability_status, $volunteer_id);
    if ($availability_stmt->execute()) {
        echo "<script>alert('Availability updated successfully');</script>";
    } else {
        echo "<script>alert('Error updating availability');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg,rgb(255, 177, 117),rgb(255, 255, 255));
            color: #333;
            animation: fadeIn 1s ease-in-out;
        }
        header {
            background: linear-gradient(90deg, #FF6F00, #FF8C00);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        main {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            border-width: 5px;
            border-color: #FF6F00;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
        }
        .dashboard-section {
            margin-bottom: 30px;
            animation: slideIn 0.8s ease-out;
            border-width: 5px;
            border-color: #FF6F00;
        }
        .dashboard-section h2 {
            font-size: 20px;
            margin-bottom: 15px;
            background: linear-gradient(90deg, #FF6F00, #FF8C00);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s, box-shadow 0.3s;
            border-width: 5px;
            border-color: #FF6F00;
        }
        .card:hover {
            transform: scale(1.02);
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.2);
        }
        button {
            background: linear-gradient(90deg, #FF6F00, #FF8C00);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background: linear-gradient(90deg, #FF8C00, #FF6F00);
        }
        canvas {
            max-width: 150%;
            height: 300px;
            border-width: 5px;
            border-color: #FF6F00;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        @keyframes slideIn {
            from {
                transform: translateY(20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome, <?= htmlspecialchars($volunteer['fullname']); ?>!</h1>
        <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
    </header>
    <main>
        <!-- My Deliveries Section -->
        <div class="dashboard-section">
            <h2>My Deliveries</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Reservation ID</th>
                            <th>User Name</th>
                            <th>Meal Name</th>
                            <th>Delivery Status</th>
                            <th>Pickup Location</th>
                            <th>Drop Location</th>
                            <th>Pickup Deadline</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($delivery = $deliveries->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($delivery['reservation_id']) ?></td>
                            <td><?= htmlspecialchars($delivery['nickname']) ?></td>
                            <td><?= htmlspecialchars($delivery['meal_name']) ?></td>
                            <td><?= htmlspecialchars($delivery['status']) ?></td>
                            <td><?= htmlspecialchars($delivery['food_bank_location']) ?></td> <!-- Pickup location -->
                            <td><?= htmlspecialchars($delivery['drop_point']) ?></td> <!-- Delivery drop location -->
                            <td><?= htmlspecialchars($delivery['pickup_deadline']) ?></td>
                            <td id="countdown-<?= $delivery['reservation_id']; ?>" style="text-align: center; font-weight: bold; color: #FF6F00;"></td> <!-- Countdown timer cell -->
                            <td>
                                <?php if ($delivery['status'] === 'pending'): ?>
                                    <form method="POST" action="">
                                        <input type="hidden" name="reservation_id" value="<?= $delivery['reservation_id'] ?>">
                                        <button type="submit" class="mark-completed">Mark as Completed</button>
                                    </form>
                                <?php else: ?>
                                    Completed
                                <?php endif; ?>
                            </td>
                        </tr>
                        <script>
                            // Initialize the countdown timer for this delivery
                            startCountdown("countdown-<?= $delivery['reservation_id']; ?>", "<?= $delivery['pickup_deadline']; ?>");
                        </script>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Availability Management Section -->
        <div class="dashboard-section">
            <h2>Set Your Availability</h2>
            <div class="card">
                <form method="POST">
                    <label for="availability_status">Choose availability status:</label>
                    <select name="availability_status" required>
                        <option value="available" <?= $volunteer['availability_status'] === 'available' ? 'selected' : '' ?>>Available</option>
                        <option value="unavailable" <?= $volunteer['availability_status'] === 'unavailable' ? 'selected' : '' ?>>Unavailable</option>
                    </select>
                    <button type="submit">Update Availability</button>
                </form>
            </div>
        </div>
    </main>
                <?php
                // Re-fetch pending deliveries
                $pending_query = "SELECT reservation_id, pickup_deadline FROM reservations WHERE volunteer_id = ? AND status = 'pending'";
                $stmt = $conn->prepare($pending_query);
                $stmt->bind_param("i", $volunteer_id);
                $stmt->execute();
                $pending_deliveries_result = $stmt->get_result();
                while ($delivery = $pending_deliveries_result->fetch_assoc()):
                ?>
                    <div class="timer" id="timer-<?= $delivery['reservation_id']; ?>"></div>
                    <script>
                        // Initialize the countdown timer for each pending delivery
                        startCountdown("timer-<?= $delivery['reservation_id']; ?>", "<?= $delivery['pickup_deadline']; ?>");
                    </script>
                <?php endwhile; ?>
            </div>
        </div>
    <!-- Completed Deliveries Chart -->
    <div class="dashboard-section">
            <h2>Your Delivery Summary</h2>
            <div class="card">
            <div style="width: 800px; height: 600px; margin: auto;">
    <canvas id="deliveriesChart"></canvas>
</div>
        </div>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('deliveriesChart').getContext('2d');
    const deliveriesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Completed Deliveries', 'Pending Deliveries'],
            datasets: [{
                label: 'Delivery Status',
                data: [<?= $completed_deliveries ?>, <?= $pending_deliveries ?>],
                backgroundColor: 'rgba(255, 111, 0, 0.5)',
                borderColor: '#FF6F00',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false, // Ensures the chart adapts to the container's size
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            size: 17
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Delivery Types',
                        font: {
                            size: 17
                        }
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Number of Deliveries',
                        font: {
                            size: 17
                        }
                    },
                    beginAtZero: true
                }
            }
        }
    });
function startCountdown(elementId, deadline) {
            var countdownElement = document.getElementById(elementId);
            var deadlineTime = new Date(deadline).getTime();
            var countdownInterval = setInterval(function () {
                var currentTime = new Date().getTime();
                var distance = deadlineTime - currentTime;
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                countdownElement.innerHTML = hours + "h " + minutes + "m " + seconds + "s ";

                if (distance < 0) {
                    clearInterval(countdownInterval);
                    countdownElement.innerHTML = "EXPIRED";
                }
            }, 1000);
        }
    </script>
</body>
</html>
