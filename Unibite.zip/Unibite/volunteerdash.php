<?php
session_start();

if (!isset($_SESSION['volunteer_id'])) {
    // Redirect to login if the session is not set
    header("Location: volunteerlogin.php");
    exit();
}
include('db_connection.php');

// Fetch logged-in volunteer's details
$volunteer_id = $_SESSION['volunteer_id'];
$query = "SELECT fullname, email, availability_status FROM volunteers WHERE volunteer_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$result = $stmt->get_result();
$volunteer = $result->fetch_assoc();

$delivery_query = "SELECT r.reservation_id, u.nickname AS nickname, d.meal_name, r.status, r.pickup_deadline, d.food_bank_location, r.drop_point, r.pickup_deadline
                   FROM reservations r
                   JOIN users u ON r.id = u.id
                   JOIN donations d ON r.donation_id = d.donation_id
                   WHERE r.volunteer_id = ?";
$stmt = $conn->prepare($delivery_query);
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$deliveries = $stmt->get_result();

// Fetch delivery data for the chart
$chart_query = "
    SELECT 
        SUM(CASE WHEN status = 'completed' AND method_of_delivery = 'delivery' THEN 1 ELSE 0 END) AS completed_deliveries,
        SUM(CASE WHEN status = 'pending' AND method_of_delivery = 'delivery' THEN 1 ELSE 0 END) AS pending_deliveries
    FROM reservations 
    WHERE volunteer_id = ?";
$stmt = $conn->prepare($chart_query);
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$chart_result = $stmt->get_result()->fetch_assoc();
$completed_deliveries = $chart_result['completed_deliveries'] ?? 0;
$pending_deliveries = $chart_result['pending_deliveries'] ?? 0;

// Handle "Mark as Completed" request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reservation_id'])) {
    $reservation_id = $_POST['reservation_id'];
    $update_query = "UPDATE reservations SET status = 'completed' WHERE reservation_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("i", $reservation_id);
    if ($update_stmt->execute()) {
        echo "<script>alert('Marked as completed');</script>";
    } else {
        echo "<script>alert('Error updating status');</script>";
    }
}

// Handle availability update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['availability_status'])) {
    $availability_status = $_POST['availability_status'];
    $update_availability_query = "UPDATE volunteers SET availability_status = ? WHERE volunteer_id = ?";
    $availability_stmt = $conn->prepare($update_availability_query);
    $availability_stmt->bind_param("si", $availability_status, $volunteer_id);
    if ($availability_stmt->execute()) {
        echo "<script>alert('Availability updated successfully');</script>";
    } else {
        echo "<script>alert('Error updating availability');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg,rgb(255, 177, 117),rgb(255, 255, 255));
            color: #333;
            animation: fadeIn 1s ease-in-out;
        }
        header {
            background: linear-gradient(90deg, #FF6F00, #FF8C00);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        main {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            border-width: 5px;
            border-color: #FF6F00;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
        }
        .dashboard-section {
            margin-bottom: 30px;
            animation: slideIn 0.8s ease-out;
            border-width: 5px;
            border-color: #FF6F00;
        }
        .dashboard-section h2 {
            font-size: 20px;
            margin-bottom: 15px;
            background: linear-gradient(90deg, #FF6F00, #FF8C00);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s, box-shadow 0.3s;
            border-width: 5px;
            border-color: #FF6F00;
        }
        .card:hover {
            transform: scale(1.02);
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.2);
        }
        button {
            background: linear-gradient(90deg, #FF6F00, #FF8C00);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background: linear-gradient(90deg, #FF8C00, #FF6F00);
        }
        canvas {
            max-width: 150%;
            height: 300px;
            border-width: 5px;
            border-color: #FF6F00;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        @keyframes slideIn {
            from {
                transform: translateY(20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    table th {
        background: linear-gradient(90deg, #FF6F00, #FF8C00);
        color: white;
        padding: 10px;
        text-align: left;
        border: 1px solid #ddd;
    }
    table td {
        padding: 10px;
        border: 1px solid #ddd;
    }
    table tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    </style>
</head>
<body>
    <header>
        <h1>Welcome, <?= htmlspecialchars($volunteer['fullname']); ?>,Volunteer!</h1>
        <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
    </header>
    <main>
        <!-- My Deliveries Section -->
        <div class="dashboard-section">
            <h2>My Deliveries</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Reservation ID</th>
                            <th>User Name</th>
                            <th>Meal Name</th>
                            <th>Delivery Status</th>
                            <th>Pickup Location</th>
                            <th>Drop Location</th>
                            <th>Pickup Deadline</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($delivery = $deliveries->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($delivery['reservation_id']) ?></td>
                            <td><?= htmlspecialchars($delivery['nickname']) ?></td>
                            <td><?= htmlspecialchars($delivery['meal_name']) ?></td>
                            <td><?= htmlspecialchars($delivery['status']) ?></td>
                            <td><?= htmlspecialchars($delivery['food_bank_location']) ?></td> <!-- Pickup location -->
                            <td><?= htmlspecialchars($delivery['drop_point']) ?></td> <!-- Delivery drop location -->
                            <td><?= htmlspecialchars($delivery['pickup_deadline']) ?></td>
                            <td>
                                <?php if ($delivery['status'] === 'pending'): ?>
                                    <form method="POST" action="">
                                        <input type="hidden" name="reservation_id" value="<?= $delivery['reservation_id'] ?>">
                                        <button type="submit" class="mark-completed">Mark as Completed</button>
                                    </form>
                                <?php else: ?>
                                    Completed
                                <?php endif; ?>
                            </td>
                        </tr>
                        <script>
                            // Initialize the countdown timer for this delivery
                            startCountdown("countdown-<?= $delivery['reservation_id']; ?>", "<?= $delivery['pickup_deadline']; ?>");
                        </script>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Availability Management Section -->
        <div class="dashboard-section">
            <h2>Set Your Availability</h2>
            <div class="card">
                <form method="POST">
                    <label for="availability_status">Choose availability status:</label>
                    <select name="availability_status" required>
                        <option value="available" <?= $volunteer['availability_status'] === 'available' ? 'selected' : '' ?>>Available</option>
                        <option value="unavailable" <?= $volunteer['availability_status'] === 'unavailable' ? 'selected' : '' ?>>Unavailable</option>
                    </select>
                    <button type="submit">Update Availability</button>
                </form>
            </div>
        </div>
    </main>
<!-- Completed Deliveries Card Section -->
<div class="dashboard-section">
    <h2>Your Delivery Summary</h2>
    <div class="card" style="padding: 20px; margin: auto; max-width: 100%; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); border-radius: 10px;">
        <div style="position: relative; height: 400px; width: 100%; max-width: 800px; margin: auto;">
            <canvas id="deliveriesChart"></canvas>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('deliveriesChart').getContext('2d');
    const deliveriesChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], // Month labels
            datasets: [{
                label: 'Completed Deliveries',
                data: [<?= $completed_deliveries ?>], // Replace with appropriate month data
                backgroundColor: 'rgba(255, 0, 0, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            },
            {
                label: 'Pending Deliveries',
                data: [<?= $pending_deliveries ?>], // Replace with appropriate month data
                backgroundColor: 'rgba(0, 34, 255, 0.7)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            size: 16
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Months',
                        font: {
                            size: 16
                        }
                    },
                    ticks: {
                        font: {
                            size: 16
                        }
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Number of Deliveries',
                        font: {
                            size: 16
                        }
                    },
                    beginAtZero: true,
                    ticks: {
                        font: {
                            size: 16
                        }
                    }
                }
            }
        }
    });
</script>

<style>
    .card {
        background-color: #fff;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .dashboard-section h2 {
        text-align: center;
        margin-bottom: 20px;
        font-family: Arial, sans-serif;
        color: #333;
    }
</style>

    </script>
</body>
</html>
