<?php
// user.php - User profile management and profile picture handling
session_start();

require 'db_connection.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['id'];

// Fetch user data from the database
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Update user information
    if (isset($_POST['fullname'], $_POST['nickname'], $_POST['email'])) {
        $fullname = $_POST['fullname'];
        $nickname = $_POST['nickname'];
        $email = $_POST['email'];

        $update_sql = "UPDATE users SET fullname = ?, nickname = ?, email = ?, updated_at = NOW() WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("sssi", $fullname, $nickname, $email, $user_id);
        $update_stmt->execute();
    }

    // Handle password update
    if (isset($_POST['current_password'], $_POST['new_password'], $_POST['confirm_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        // Verify current password
        if (password_verify($current_password, $user['password'])) {
            if ($new_password === $confirm_password) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update the password
                $password_sql = "UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?";
                $password_stmt = $conn->prepare($password_sql);
                $password_stmt->bind_param("si", $hashed_password, $user_id);
                $password_stmt->execute();
            }
        }
    }

    // Handle profile picture upload
    if (isset($_FILES['profile_picture'])) {
        $target_dir = "uploads/";
        $profile_picture = $target_dir . basename($_FILES['profile_picture']['name']);

        // Upload the file and update the database
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profile_picture)) {
            $picture_sql = "UPDATE users SET profile_picture = ?, updated_at = NOW() WHERE id = ?";
            $picture_stmt = $conn->prepare($picture_sql);
            $picture_stmt->bind_param("si", $profile_picture, $user_id);
            $picture_stmt->execute();
        }
    }

    // Refresh user data
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - UniBite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background: linear-gradient(to right,rgb(255, 209, 196),rgb(255, 244, 238)); /* Gradient background */
        color: #333;
        font-family: Arial, sans-serif;
    }

    .navbar {
        background: linear-gradient(90deg, #ff5722, #ff9800); /* Match header gradient */
        border-bottom: 2px solid #ff5500; /* Highlight navbar */
    }

    .navbar .navbar-brand,
    .navbar .nav-link {
        color: white;
        font-weight: bold;
    }

    .navbar .nav-link:hover {
        color: #ffe6d5;
    }

    .container {
        margin-top: 30px;
        background-color: #fff; /* Card background */
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
    }

    h2,
    h5 {
        background: linear-gradient(to right, #ff9966, #ff7247);
        color: white;
        font-weight: bold;
        padding: 10px;
        border-radius: 5px;
        text-align: center;
    }

    .profile-picture {
        border-radius: 50%;
        width: 120px;
        height: 120px;
        object-fit: cover;
        border: 3px solid #ff7247;
    }

    .btn {
        font-weight: bold; /* Bold buttons */
        border-radius: 30px; /* Rounded buttons */
    }

    .btn-primary {
        background: linear-gradient(to right, #4e54c8, #8f94fb);
        border: none;
    }

    .btn-primary:hover {
        background: linear-gradient(to right, #3b3fc0, #6b70f2);
    }

    .btn-warning {
        background: linear-gradient(to right, #ff9966, #ff7247);
        border: none;
    }

    .btn-warning:hover {
        background: linear-gradient(to right, #ff7747, #ff5522);
    }

    .btn-success {
        background: linear-gradient(to right, #56ab2f, #a8e063);
        border: none;
    }

    .btn-success:hover {
        background: linear-gradient(to right, #45a024, #8bd458);
    }

    .input-group-text {
        font-weight: bold; /* Bold labels */
    }
/* Footer */
footer {
    text-align: center;
    padding: 20px 0;
    background: linear-gradient(90deg, #ff6e40, #ffa726);
    color: #fff;
    margin-top: 30px;
    font-size: 14px;
    font-weight: bold;
}
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#">UniBite</a>
        <ul class="navbar-nav ml-auto">
            <li><a href="index.php" class="nav-link">Home</a></li>
            <li><a href="logout.php" class="nav-link">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <h2 class="text-center mb-4">Your Profile</h2>
        <div class="card p-4">
            <div class="row">
                <div class="col-md-4 text-center">
                    <!-- Display Profile Picture -->
                    <img src="<?= $user['profile_picture'] ? 'uploads/' . $user['profile_picture'] : 'uploads/default_profile.png' ?>" 
     class="profile-picture mb-3" 
     alt="Profile Picture">


                    <!-- Change Profile Picture -->
                    <form action="user.php" method="POST" enctype="multipart/form-data">
                        <input type="file" class="form-control mb-2" name="profile_picture" required>
                        <button type="submit" class="btn btn-primary w-100">Upload New Picture</button>
                    </form>
                </div>
                <div class="col-md-8">
                    <!-- Update Profile Information -->
                    <form action="user.php" method="POST">
                        <div class="input-group">
                            <span class="input-group-text">Full Name</span>
                            <input type="text" class="form-control" name="fullname" value="<?= $user['fullname'] ?>" required>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text">Nickname</span>
                            <input type="text" class="form-control" name="nickname" value="<?= $user['nickname'] ?>" required>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text">Email</span>
                            <input type="email" class="form-control" name="email" value="<?= $user['email'] ?>" required>
                        </div>
                        <button type="submit" class="btn btn-warning w-100 mt-3">Save Changes</button>
                    </form>

                    <!-- Update Password -->
                    <form action="user.php" method="POST" class="mt-4">
                        <h5>Change Password</h5>
                        <div class="input-group">
                            <span class="input-group-text">Current Password</span>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text">New Password</span>
                            <input type="password" class="form-control" name="new_password" required>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text">Confirm Password</span>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100 mt-3">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center mt-4">
        <p>&copy; 2025 UniBite - All Rights Reserved</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
