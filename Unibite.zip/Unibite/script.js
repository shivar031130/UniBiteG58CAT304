// Validate the donation form before submission
document.getElementById("donateForm").addEventListener("submit", function(event) {
    // Get form inputs
    const mealName = document.getElementById("mealName").value;
    const mealDescription = document.getElementById("mealDescription").value;
    const mealImage = document.getElementById("mealImage").files[0];
    const mealQuantity = document.getElementById("mealQuantity").value;
    const pickupDelivery = document.getElementById("pickupDelivery").value;
    const foodBankLocation = document.getElementById("foodBankLocation").value;
    const contactInfo = document.getElementById("contactInfo").value;

    // Clear previous error messages
    clearErrors();

    let isValid = true;

    // Check if meal name is empty
    if (!mealName.trim()) {
        showError("mealName", "Meal name is required.");
        isValid = false;
    }

    // Check if meal description is empty
    if (!mealDescription.trim()) {
        showError("mealDescription", "Meal description is required.");
        isValid = false;
    }

    // Check if meal image is uploaded
    if (!mealImage) {
        showError("mealImage", "Meal image is required.");
        isValid = false;
    }

    // Check if meal quantity is valid
    if (!mealQuantity || mealQuantity <= 0) {
        showError("mealQuantity", "Quantity must be greater than zero.");
        isValid = false;
    }

    // Check if pickup/delivery option is selected
    if (!pickupDelivery) {
        showError("pickupDelivery", "Please select an option for pickup or delivery.");
        isValid = false;
    }

    // Check if food bank location is selected
    if (!foodBankLocation) {
        showError("foodBankLocation", "Please select a food bank location.");
        isValid = false;
    }

    // Check if contact info is provided
    if (!contactInfo.trim()) {
        showError("contactInfo", "Your contact information is required.");
        isValid = false;
    }

    // Prevent form submission if validation fails
    if (!isValid) {
        event.preventDefault();
    }
});

// Function to show error message next to the input field
function showError(fieldId, message) {
    const inputField = document.getElementById(fieldId);
    const errorDiv = document.createElement("div");
    errorDiv.classList.add("error-message");
    errorDiv.textContent = message;

    inputField.classList.add("input-error");

    // Append the error message after the input field
    inputField.insertAdjacentElement("afterend", errorDiv);
}

// Function to clear error messages
function clearErrors() {
    // Clear input error styles and error messages
    const errorMessages = document.querySelectorAll(".error-message");
    const inputFields = document.querySelectorAll(".input-error");

    errorMessages.forEach(error => error.remove());
    inputFields.forEach(input => input.classList.remove("input-error"));
}
