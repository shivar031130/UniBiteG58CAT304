<?php
// Include database connection
include('db_connection.php');

// Start the session
session_start();

// Check if the user is already logged in
if (isset($_SESSION['id'])) {
    // Destroy the session and log the user out
    session_unset();   // Unset all session variables
    session_destroy(); // Destroy the session
}

// Redirect to the confirmation page after a short delay
header("Refresh: 2; URL=signup_options.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - Successful</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .logout-container {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #ff7247;
        }
        p {
            font-size: 1.2rem;
            color: #333;
        }
        .redirect-message {
            font-size: 1rem;
            margin-top: 20px;
            color: #888;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #ff7247;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        a:hover {
            background-color: #e05c3b;
        }
    </style>
</head>
<body>

    <div class="logout-container">
        <h1>Successfully Logged Out!</h1>
        <p>You have logged out of your account successfully.</p>
        <div class="redirect-message">
            You will be redirected to the Sign-Up page shortly. If not, click the button below.
        </div>
        <a href="signup_options.php">Return to Sign-Up Option</a>
    </div>

</body>
</html>
