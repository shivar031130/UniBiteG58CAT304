<?php
// Start session and include database connection
session_start();
include('db_connection.php');

// Get logged-in user ID
$id = $_SESSION['id'];

// Handle QR Code Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['qr_code'])) {
    $reservation_id = $_POST['reservation_id'];

    // Ensure the file is uploaded
    if ($_FILES['qr_code']['error'] === UPLOAD_ERR_OK) {
        $tmp_file = $_FILES['qr_code']['tmp_name'];
        $file_content = file_get_contents($tmp_file);

        // Send the QR code image to ZXing API for decoding
        $boundary = uniqid();
        $headers = [
            "Content-Type: multipart/form-data; boundary=" . $boundary
        ];
        $body = "--" . $boundary . "\r\n" .
                "Content-Disposition: form-data; name=\"file\"; filename=\"qr.png\"\r\n" .
                "Content-Type: image/png\r\n\r\n" .
                $file_content . "\r\n" .
                "--" . $boundary . "--";

        $url = "https://zxing.org/w/decode";
        $context = stream_context_create([
            "http" => [
                "method" => "POST",
                "header" => implode("\r\n", $headers),
                "content" => $body,
            ]
        ]);

        $response = file_get_contents($url, false, $context);

        // Check if the response contains the decoded text
        if ($response) {
            // Extract the decoded text using regex
            if (preg_match('/<pre>(.*?)<\/pre>/s', $response, $matches)) {
                $decoded_text = trim($matches[1]);

                // Verify if the decoded text matches the reservation ID
                if (strpos($decoded_text, "Reservation ID: $reservation_id") !== false) {
                    // Update reservation status to 'Completed'
                    $update_query = "UPDATE reservations SET status = 'completed' WHERE reservation_id = ? AND id = ?";
                    $stmt = $conn->prepare($update_query);
                    $stmt->bind_param("ii", $reservation_id, $id);
                    $stmt->execute();

                    echo "<p style='color: green;'>QR Code verified successfully. Reservation marked as completed!</p>";
                } else {
                    echo "<p style='color: red;'>Invalid QR Code or Reservation ID mismatch.</p>";
                }
            } else {
                echo "<p style='color: red;'>Failed to decode QR Code. Please try again.</p>";
            }
        } else {
            echo "<p style='color: red;'>Failed to decode QR Code. Please try again.</p>";
        }
    } else {
        echo "<p style='color: red;'>Error uploading QR Code. Please try again.</p>";
    }
}

// Fetch reservations for the logged-in user
$query = "SELECT r.reservation_id, r.reservation_date, r.status, r.method_of_delivery, r.drop_point, r.delivery_address, d.meal_name, r.pickup_deadline
          FROM reservations r 
          JOIN donations d ON r.donation_id = d.donation_id
          WHERE r.id = ? 
          ORDER BY r.reservation_date DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$reservations = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation History</title>
    <style>
        /* General Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #fef9f4;
            color: #333;
            line-height: 1.6;
        }

        /* Navbar Styling */
        nav.navbar {
            background: linear-gradient(90deg, #ff6e40, #ffa726);
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        nav.navbar .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #fff;
            text-decoration: none;
        }

        nav.navbar .nav-link {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            padding: 8px 12px;
            border-radius: 4px;
            transition: background 0.3s ease, color 0.3s ease;
        }

        nav.navbar .nav-link:hover {
            background-color: #fff;
            color: #ff6e40;
        }

        /* Main Content */
        main {
            max-width: 1200px;
            margin: 30px auto;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
        }

        /* Table */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        table th, table td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
            font-size: 16px;
            font-weight: bold;
        }

        table th {
            background: linear-gradient(90deg, #ff6e40, #ffa726);
            color: white;
            font-weight: 600;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #ffe5d4;
        }

        /* Buttons */
        button, .home-button {
            background: linear-gradient(90deg, #ff6e40, #ffa726);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        button:hover, .home-button:hover {
            background: linear-gradient(90deg, #ff5722, #ff9800);
            transform: translateY(-2px);
            box-shadow: 0px 8px 20px rgba(255, 110, 64, 0.5);
        }

        /* Messages */
        .success-message {
            color: green;
            font-weight: 600;
        }

        .error-message {
            color: red;
            font-weight: 600;
        }
        /* Footer Styling */
    footer {
        text-align: center;
        padding: 20px 0;
        background: linear-gradient(90deg, #ff6e40, #ffa726);
        color: #fff;
        margin-top: 30px;
        font-size: 14px;
    }
    </style>
</head>
<body>
<nav class="navbar">
    <a class="navbar-brand" href="#">UniBite</a>
    <div class="navbar-links">
        <a href="index.php" class="nav-link">Home</a>
        <a href="donate.php" class="nav-link">Donate</a>
        <a href="services.php" class="nav-link">Services</a>
        <a href="contact.php" class="nav-link">Contact</a>
        <a href="aboutus.php" class="nav-link">About Us</a>
        <a href="logout.php" class="nav-link login">Logout</a>
    </div>
</nav>
    <main>
        <?php if ($reservations->num_rows > 0): ?>
            <table>
            <h2>Your Reservation History</h2>
                <thead>
                    <tr>
                        <th>Meal Name</th>
                        <th>Reservation Date</th>
                        <th>Pickup Deadline</th>
                        <th>Status</th>
                        <th>Delivery Method</th>
                        <th>Drop Point</th>
                        <th>Delivery Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($reservation = $reservations->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($reservation['meal_name']) ?></td>
                            <td><?= htmlspecialchars($reservation['reservation_date']) ?></td>
                            <td><?= htmlspecialchars($reservation['pickup_deadline']) ?></td>
                            <td><?= htmlspecialchars($reservation['status']) ?></td>
                            <td><?= htmlspecialchars($reservation['method_of_delivery']) ?></td>
                            <td><?= htmlspecialchars($reservation['drop_point']) ?></td>
                            <td><?= htmlspecialchars($reservation['delivery_address']) ?></td>
                            <td>
                                <?php if ($reservation['status'] === 'pending'): ?>
                                    <form method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="reservation_id" value="<?= htmlspecialchars($reservation['reservation_id']) ?>">
                                        <input type="file" name="qr_code" accept="image/*" required>
                                        <button type="submit">Upload QR Code</button>
                                    </form>
                                <?php else: ?>
                                    Completed
                                    <form action="feedback.php" method="GET" style="margin-top: 10px;">
                                        <input type="hidden" name="reservation_id" value="<?= htmlspecialchars($reservation['reservation_id']) ?>">
                                        <button type="submit">Submit Feedback</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No reservations found.</p>
        <?php endif; ?>
         <!-- Home Button -->
         <a href="dashboard.php">
                <button class="home-button">Back to Dashboard</button>
            </a>
        </div>
    </main>
    <footer>
        <p>&copy; 2025 UniBite. All rights reserved.</p>
    </footer>
    </main>
</body>
</html>
