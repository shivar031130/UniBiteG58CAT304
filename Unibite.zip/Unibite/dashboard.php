<?php
session_start();
include('db_connection.php'); // Include database configuration

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['id']; // Get the user ID from the session

// Fetch user details
$sql_user = "SELECT fullname FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("i", $id);
$stmt_user->execute();
$user_result = $stmt_user->get_result();
$user = $user_result->fetch_assoc();
$fullname = $user['fullname'];

// Fetch reservations count for the user
$sql_reservations = "SELECT COUNT(*) AS count FROM reservations WHERE id = ?";
$stmt_reservations = $conn->prepare($sql_reservations);
$stmt_reservations->bind_param("i", $id);
$stmt_reservations->execute();
$reservations_result = $stmt_reservations->get_result();
$reservations = $reservations_result->fetch_assoc();

// Fetch donations count for the user
$sql_donations = "SELECT COUNT(*) AS count FROM donations WHERE id = ?";
$stmt_donations = $conn->prepare($sql_donations);
$stmt_donations->bind_param("i", $id);
$stmt_donations->execute();
$donations_result = $stmt_donations->get_result();
$donations = $donations_result->fetch_assoc();

// Fetch monthly reservations data for the user
$reservations_query = "SELECT MONTH(reservation_date) AS month, COUNT(*) AS count 
                       FROM reservations WHERE id = ? 
                       GROUP BY MONTH(reservation_date)";
$stmt_reservations_month = $conn->prepare($reservations_query);
$stmt_reservations_month->bind_param("i", $id);
$stmt_reservations_month->execute();
$reservations_result_month = $stmt_reservations_month->get_result();
$reservations_data = array_fill(1, 12, 0); // Initialize array for all months
while ($row = $reservations_result_month->fetch_assoc()) {
    $reservations_data[intval($row['month'])] = intval($row['count']);
}

// Fetch monthly donations data for the user
$donations_query = "SELECT MONTH(donation_date) AS month, COUNT(*) AS count 
                    FROM donations WHERE id = ? 
                    GROUP BY MONTH(donation_date)";
$stmt_donations_month = $conn->prepare($donations_query);
$stmt_donations_month->bind_param("i", $id);
$stmt_donations_month->execute();
$donations_result_month = $stmt_donations_month->get_result();
$donations_data = array_fill(1, 12, 0); // Initialize array for all months
while ($row = $donations_result_month->fetch_assoc()) {
    $donations_data[intval($row['month'])] = intval($row['count']);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UniBite Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
    :root {
      --primary-color: #ff7247;
      --secondary-color:rgb(255, 221, 207);
    }

    body {
      background-color: var(--secondary-color);
      color:rgb(255, 255, 255);
    }

    .sidebar {
      background-color: var(--primary-color);
      color: #fff;
      height: 100vh;
      width: 250px;
      position: fixed;
      top: 0;
      left: 0;
      padding: 20px;
    }

    .sidebar h2 {
      color: #fff;
      font-size: 1.5rem;
      text-align: center;
      margin-bottom: 30px;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li {
      margin: 15px 0;
    }

    .sidebar ul li a {
      text-decoration: none;
      color: #fff;
      font-size: 1.1rem;
      display: flex;
      align-items: center;
      gap: 20px;
    }

    .sidebar ul li a:hover {
      color: #dcdcdc;
    }

    .main-content {
      margin-left: 250px;
      padding: 20px;
    }

    .card {
      border: none;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
    }

    .chart-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 600px; /* Increased chart container height */
    }

    canvas {
        width: 100% !important; /* Increased chart width */
        height: 100% !important; /* Increased chart height */
    }

    footer {
      text-align: center;
      margin-top: 20px;
      font-size: 0.8rem;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      background-color: rgba(0, 0, 0, 0.8);
    }

    header .logo {
      display: flex;
      align-items: center;
    }

    header .logo img {
      width: 50px;
      margin-right: 10px;
      border-radius: 50%;
    }

    header h1 {
      color: #ff5100;
    }

    header nav ul {
      display: flex;
      list-style: none;
    }

    header nav ul li {
      margin: 0 10px;
    }

    header nav ul li a {
      color: #fff;
      text-decoration: none;
      font-size: 1.1rem;
      transition: all 0.3s ease;
    }

    header nav ul li a:hover {
      color: #ff5900;
      transform: scale(1.1);
    }

    header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color: rgba(0, 0, 0, 0.8);
}

header .logo {
    display: flex;
    align-items: center;
}

header .logo img {
    width: 50px;
    margin-right: 10px;
    border-radius: 50%;
}

header h1 {
    color: #ff5100;
}

header .user-info {
    flex: 1;
    text-align: left;
}

header .user-info h2 {
    margin: 0;
    color: white;
    font-size: 1.5rem;
}

header nav {
    display: flex;
    align-items: center;
}

header nav ul {
    display: flex;
    list-style: none;
    margin-left: auto;
}

header nav ul li {
    margin: 0 10px;
}

header nav ul li a {
    color: #fff;
    text-decoration: none;
    font-size: 1.1rem;
    transition: all 0.3s ease;
}

header nav ul li a:hover {
    color: #ff5900;
    transform: scale(1.1);
}


/* Footer */
footer {
    text-align: center;
    padding: 20px 0;
    background: linear-gradient(90deg, #ff6e40, #ffa726);
    color: #fff;
    margin-top: 30px;
    font-size: 14px;
}
  </style>
</head>
<body>

<!-- Header Section -->
<header>
    <div class="logo">
        <img src="assets/logo.png" alt="UniBite Logo">
        <h1>UniBite</h1>
    </div>
    <nav>
    <h1>Welcome, <?= htmlspecialchars($fullname); ?>!</h1> <!-- Display full name here -->
        <ul>
            <li><a href="index.php" class="nav-link">Home</a></li>
            <li><a href="donate.php" class="nav-link">Donate</a></li>
            <li><a href="services.html" class="nav-link">Services</a></li>
            <li><a href="contact.html" class="nav-link">Contact</a></li>
            <li><a href="aboutus.html" class="nav-link">About Us</a></li>
            <li><a href="logout.php" class="nav-link login">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Sidebar Section -->
<div class="sidebar">
    <h2>UniBite</h2>
    <ul>
        <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="reservationhis.php"><i class="fas fa-calendar-check"></i> Reservations</a></li>
        <li><a href="donationhis.php"><i class="fas fa-box"></i> Donation History</a></li>
        <li><a href="user.php"><i class="fas fa-users"></i> User Management</a></li>
        <li><a href="feedback.php"><i class="fas fa-comments"></i> Feedback</a></li>
    </ul>
</div>

<!-- Main Content Section -->
<div class="main-content">
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-center" id="reservationsCard">
                <div class="card-body">
                    <h6>My Reservations</h6>
                    <h3><?php echo $reservations['count']; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center" id="donationsCard">
                <div class="card-body">
                    <h6>My Donations</h6>
                    <h3><?php echo $donations['count']; ?></h3>
                </div>
            </div>
        </div>
    </div>
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Reservations Overview</h5>
                        <canvas id="reservationsChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Donations Overview</h5>
                        <canvas id="donationsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer>
        &copy; 2025 UniBite User Dashboard
    </footer>

    <!-- Pass PHP Data to JavaScript -->
    <script>
        // PHP data to JavaScript
        const reservationsData = <?php echo json_encode(array_values($reservations_data)); ?>;
        const donationsData = <?php echo json_encode(array_values($donations_data)); ?>;
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

        // Chart for Reservations
        const reservationsChartCtx = document.getElementById("reservationsChart").getContext("2d");
        new Chart(reservationsChartCtx, {
            type: "line",
            data: {
                labels: months,
                datasets: [{
                    label: "Reservations",
                    data: reservationsData,
                    borderColor: "rgba(255, 114, 71, 1)",
                    backgroundColor: "rgba(255, 114, 71, 0.2)",
                    borderWidth: 2,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Chart for Donations
        const donationsChartCtx = document.getElementById("donationsChart").getContext("2d");
        new Chart(donationsChartCtx, {
            type: "bar",
            data: {
                labels: months,
                datasets: [{
                    label: "Donations",
                    data: donationsData,
                    backgroundColor: "rgba(71, 114, 255, 0.8)",
                    borderColor: "rgba(71, 114, 255, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    </script>
</body>
</html>