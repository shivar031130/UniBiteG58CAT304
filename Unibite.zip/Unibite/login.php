<?php
session_start();
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email exists in the database
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User found
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            if ($user['is_verified'] == 1) {
                if ($user['status'] == 'active') {
                    // Allow login for active users
                    $_SESSION['id'] = $user['id'];
                    $_SESSION['fullname'] = $user['fullname'];
                    $_SESSION['user_role'] = $user['user_role'];
        
                    // Redirect to dashboard
                    header("Location: dashboard.php");
                    exit();
                } elseif ($user['status'] == 'suspended') {
                    $error_message = "Your account has been suspended. Please contact support.";
                } elseif ($user['status'] == 'removed') {
                    $error_message = "Your account has been removed.";
                }
            } else {
                $error_message = "Your account is not verified. Please wait for admin approval.";
            }
        } else {
            $error_message = "Invalid password.";
        }
        
    } else {
        $error_message = "No user found with this email address.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #fdf3f0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header .logo {
            display: flex;
            align-items: center;
        }

        header .logo img {
            width: 60px;
            margin-right: 10px;
        }

        header nav ul {
            display: flex;
            list-style: none;
        }

        header nav ul li {
            margin: 0 10px;
        }

        header nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        header nav ul li a:hover {
            color: #000;
        }

        header nav ul li .login {
            background-color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            color: #ff7247;
        }

        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin-top: 50px;
        }

        .form-box {
            width: 100%;
            max-width: 500px;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .form-box h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 2rem;
            color: #ff7247;
        }

        .form-box label {
            font-size: 1.1rem;
            color: #333;
        }

        .form-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1rem;
        }

        .form-box button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-box button:hover {
            background-color: #e05c3b;
        }

        .form-box p {
            text-align: center;
            margin-top: 20px;
            font-size: 1rem;
        }

        .form-box a {
            color: #ff7247;
            text-decoration: none;
            font-weight: bold;
        }

        .form-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="assets/logo1.png" alt="UniBite Logo">
            <h1>UniBite</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="donate.php">Donate</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="contactus.html">Contact</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="signup_option.php" class="login">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <div class="form-container">
        <div class="form-box">
            <h2>Login</h2>
            <?php if (!empty($error_message)): ?>
                <div style="color: red; text-align: center; margin-bottom: 10px;">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            <form method="POST">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Login</button>
            </form>
            <p>Don't have an account? <a href="signup_options.php">Sign Up</a></p>
        </div>
    </div>
</body>
</html>
