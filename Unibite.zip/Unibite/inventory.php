<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unibite"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch food items from the donations table where expiry_date >= current date using MySQL's CURDATE()
$sql = "SELECT * FROM donations WHERE expiry_date >= CURDATE()";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Available Food</title>
</head>
<style>/* General styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color:rgb(255, 225, 214);
  }
  
/* Header */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 10px;
    background-color: rgba(0, 0, 0, 0.85);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

header .logo {
    display: flex;
    align-items: center;
}

header .logo img {
    width: 40px; /* Smaller logo */
    height: auto;
    margin-right: 10px;
}

header h1 {
    font-size: 1.5rem;
    color: #ff5100;
    margin: 0;
}

header nav ul {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
}

header nav ul li {
    margin: 0 10px;
}

header nav ul li a {
    color: #fff;
    text-decoration: none;
    font-size: 1.1rem;
    font-weight: 500;
    padding: 5px 5px;
    transition: color 0.3s ease, transform 0.3s ease;
}

header nav ul li a:hover {
    color: #ff7200;
    transform: translateY(-2px);
}

header nav ul li a.login {
    background: #ff5500;
    color: #fff;
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: bold;
    transition: background 0.3s ease;
}

header nav ul li a.login:hover {
    background: #ff7200;
}

/* Keyframes */
@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}
  
  .inventory-section h2 {
    text-align: center;
    margin-bottom: 20px;
  }
  
  /* Food grid and card layout */
  .food-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 40px;
  padding: 13px;
}

.food-card {
  background: linear-gradient(90deg, #ff6e40, #ffa726);
  border-radius: 10px;
  box-shadow: 0 6px 8px rgba(0, 0, 0, 0.87);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  transition: transform 0.5s ease, box-shadow 0.5s ease; /* Smooth transitions for hover effects */
}

.food-card:hover {
  transform: translateY(-10px); /* Move card up by 10px */
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.7); /* Add a stronger shadow for a floating effect */
}

.food-image-container {
  background-color: #fff;
  height: 150px;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: stretch;
}
  
  .food-image {
    max-height: 100%;
    max-width: 150%;
    object-fit: stretch;
  }
  
  .food-details {
    padding: 20px;
  }
  
  .food-title {
    font-size: 1.6em;
    font-weight: bold;
    margin-bottom: 10px;
    text-align: center;
    color: white;
    stroke: black;
    stroke-width: 2px;
    text-transform: uppercase;
  }
  
  .food-details ul {
    list-style: none;
    padding: 5px;
  }
  
  .food-details ul li {
    margin-bottom: 5px;
  }
  
  .reserve-btn {
    background-color:rgb(35, 160, 0);
    color: white;
    text-decoration: none;
    display: block;
    text-align: center;
    padding: 10px;
    border-radius: 5px;
    margin-top: 10px;
    font-weight: bold;
  }
  
  .reserve-btn:hover {
    background-color:rgb(0, 246, 12);
  }
  
  /* Footer */
.footer {
    background: #333;
    color: #fff;
    padding: 20px;
    text-align: center;
    font-size: 1rem;
    margin-top: 20px;
    border-top: 4px solid #ff7f50;
}

.footer p {
    margin: 0;
}

.footer a {
    color: #ff7f50;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s ease;
}

.footer a:hover {
    color: #ffa07a;
}
  </style>
<body>
  <header>
    <div class="logo">
      <img src="assets/logo1.png" alt="UniBite Logo">
      <h1>UniBite</h1>
    </div>
    <nav>
      <ul>
        <li><a href="index.php" class="nav-link">Home</a></li>
        <li><a href="donate.php" class="nav-link">Donate</a></li>
        <li><a href="services.html" class="nav-link">Services</a></li>
        <li><a href="contact.html" class="nav-link">Contact</a></li>
        <li><a href="aboutus.html" class="nav-link">About Us</a></li>
        <li><a href="logout.php" class="nav-link login">Logout</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="inventory-section">
      <h2>Available Food Items</h2>
      <div id="food-list" class="food-grid">
        <?php
// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Loop through each row and display food cards
    while ($row = $result->fetch_assoc()) {
        $expiry_date = $row['expiry_date'];

        // Display food item details
        echo '<div class="food-card">
                <div class="food-image-container">
                  <img src="meal_images/'.$row['meal_image'].'" alt="'.$row['meal_name'].'" class="food-image">
                </div>
                <div class="food-details">
                  <div class="food-title">'.$row['meal_name'].'</div>
                  <ul>
                    <li><strong>Description:</strong> '.$row['meal_description'].'</li>
                    <li><strong>Location:</strong> '.$row['food_bank_location'].'</li>
                    <li><strong>Quantity:</strong> '.$row['meal_quantity'].'</li>
                    <li><strong>Delivery Method:</strong> '.$row['pickup_delivery'].'</li>
                    <li><strong>Expiry Date:</strong> '.$expiry_date.'</li>
                  </ul>
                  <a href="reserve.php?donation_id='.$row['donation_id'].'" class="reserve-btn">Reserve Item</a>
                </div>
              </div>';
    }
} else {
    echo "<p>No food items available.</p>";
}
?>
      </div>
    </section>
  </main>

  <footer class="footer">
    <p>&copy; 2025 UniBite Food Bank System</p>
  </footer>

  <script src="main.js"></script>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
