<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unibite"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch food items from the donations table where expiry_date >= current date using MySQL's CURDATE()
$sql = "SELECT * FROM donations WHERE expiry_date >= CURDATE()";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Available Food</title>
  <link rel="stylesheet" href="inventory.css">
</head>
<body>
  <header>
    <div class="logo">
      <img src="assets/logo.png" alt="UniBite Logo">
      <h1>UniBite</h1>
    </div>
    <nav>
      <ul>
        <li><a href="index.php" class="nav-link">Home</a></li>
        <li><a href="donate.php" class="nav-link">Donate</a></li>
        <li><a href="services.html" class="nav-link">Services</a></li>
        <li><a href="contact.html" class="nav-link">Contact</a></li>
        <li><a href="aboutus.html" class="nav-link">About Us</a></li>
        <li><a href="logout.php" class="nav-link login">Logout</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="inventory-section">
      <h2>Available Food Items</h2>
      <div id="food-list" class="food-grid">
        <?php
// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Loop through each row and display food cards
    while ($row = $result->fetch_assoc()) {
        $expiry_date = $row['expiry_date'];

        // Display food item details
        echo '<div class="food-card">
                <div class="food-image-container">
                  <img src="meal_images/'.$row['meal_image'].'" alt="'.$row['meal_name'].'" class="food-image">
                </div>
                <div class="food-details">
                  <h3>'.$row['meal_name'].'</h3>
                  <p>Description: '.$row['meal_description'].'</p>
                  <p>Location: '.$row['food_bank_location'].'</p>
                  <p>Quantity: '.$row['meal_quantity'].'</p>
                  <p>Delivery Method: '.$row['pickup_delivery'].'</p>
                  <p>Expiry Date: '.$expiry_date.'</p>
                  <a href="reserve.php?donation_id='.$row['donation_id'].'" class="reserve-btn">Reserve Item</a>
                </div>
              </div>';
    }
} else {
    echo "<p>No food items available.</p>";
}
?>
      </div>
    </section>
  </main>

  <footer class="footer">
    <p>&copy; 2025 UniBite Food Bank System</p>
  </footer>

  <script src="main.js"></script>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>