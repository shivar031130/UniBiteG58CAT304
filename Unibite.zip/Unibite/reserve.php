<?php
// Start session and include database connection
session_start();
include('db_connection.php');

// Get logged-in user ID
$id = $_SESSION['id'];

// Get the donation details from the database
$donation_id = $_GET['donation_id'] ?? null;
if ($donation_id) {
    $query = "SELECT * FROM donations WHERE donation_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $donation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $donation = $result->fetch_assoc();
}

// Fetch volunteers for delivery
$volunteers_sql = "SELECT volunteer_id, fullname FROM volunteers WHERE availability_status = 'available'";
$volunteers = $conn->query($volunteers_sql);

// Handle reservation submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $method = $_POST['method'] ?? null;
    $quantity = $_POST['quantity'] ?? null;
    $drop_point = $_POST['drop_point'] ?? null;
    $delivery_address = $_POST['address'] ?? null;
    $volunteer_id = $_POST['volunteer_id'] ?? null;
    $pickup_deadline = $_POST['pickup_deadline'] ?? null;

    // Validate inputs
    if (!$method) {
        $error_message = "Please select a delivery method.";
    } elseif ($method === 'pickup' && $donation['pickup_delivery'] === 'delivery') {
        $error_message = "This food is available for delivery only.";
    } elseif ($method === 'delivery' && $donation['pickup_delivery'] === 'pickup') {
        $error_message = "This food is available for pickup only.";
    } elseif ($quantity <= 0 || $quantity > $donation['meal_quantity']) {
        $error_message = "Invalid quantity selected.";
    } elseif ($method === 'delivery' && empty($volunteer_id)) {
        $error_message = "Please select a volunteer for delivery.";
    } else {
        // If pickup only, set volunteer_id to NULL
        if ($method === 'pickup') {
            $volunteer_id = NULL;
        }

        // Begin transaction
        $conn->begin_transaction();

        try {
            // Insert into reservations table
            $query = "INSERT INTO reservations (id, donation_id, reservation_date, delivery_address, status, method_of_delivery, drop_point, volunteer_id, pickup_deadline)
                      VALUES (?, ?, NOW(), ?, 'Pending', ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);

            if ($volunteer_id) {
                $stmt->bind_param("iisssis", $id, $donation_id, $delivery_address, $method, $drop_point, $volunteer_id, $pickup_deadline);
            } else {
                $stmt->bind_param("iisssis", $id, $donation_id, $delivery_address, $method, $drop_point, $volunteer_id, $pickup_deadline);
            }

            if (!$stmt->execute()) {
                throw new Exception("Failed to create reservation.");
            }

            // Update the donations table to reduce the quantity
            $update_query = "UPDATE donations SET meal_quantity = meal_quantity - ? WHERE donation_id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("ii", $quantity, $donation_id);

            if (!$update_stmt->execute()) {
                throw new Exception("Failed to update donation quantity.");
            }

            // Commit the transaction
            $conn->commit();

            // Redirect to confirmation page
            header("Location: reserve_confirmation.php?reservation_id=" . $stmt->insert_id);
            exit;
        } catch (Exception $e) {
            // Rollback transaction if something goes wrong
            $conn->rollback();
            $error_message = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserve Food</title>
    <link rel="stylesheet" href="reserve.css">
</head>
<body>
    <header>
        <h1>Reserve Food</h1>
    </header>
    <main>
        <div class="card">
            <h2><?= htmlspecialchars($donation['meal_name'] ?? 'Food Not Found') ?></h2>
            <?php if (!empty($donation['meal_image'])): ?>
                <img src="meal_images/<?= htmlspecialchars($donation['meal_image']) ?>" alt="Meal Image" class="meal-image">
            <?php else: ?>
                <img src="meal_images/default.png" alt="Default Meal Image" class="meal-image">
            <?php endif; ?>
            <p><?= htmlspecialchars($donation['meal_description'] ?? 'No description available.') ?></p>
            <p><strong>Available Quantity:</strong> <?= htmlspecialchars($donation['meal_quantity'] ?? 0) ?></p>
            <p><strong>Delivery Method Available:</strong> <?= htmlspecialchars(ucfirst($donation['pickup_delivery'] ?? 'Unavailable')) ?></p>
        </div>

        <?php if (isset($error_message)): ?>
            <p class="error"><?= $error_message ?></p>
        <?php endif; ?>

        <form method="POST" action="reserve.php?donation_id=<?= htmlspecialchars($donation_id) ?>">
            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input type="number" id="quantity" name="quantity" min="1" max="<?= htmlspecialchars($donation['meal_quantity'] ?? 1) ?>" required>
            </div>

            <div class="form-group">
                <label for="method">Delivery Method</label>
                <select id="method" name="method" required onchange="toggleDeliveryFields(this.value)">
                    <option value="">Select Method</option>
                    <?php if ($donation['pickup_delivery'] === 'both' || $donation['pickup_delivery'] === 'pickup'): ?>
                        <option value="pickup">Pickup</option>
                    <?php endif; ?>
                    <?php if ($donation['pickup_delivery'] === 'both' || $donation['pickup_delivery'] === 'delivery'): ?>
                        <option value="delivery">Delivery</option>
                    <?php endif; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="pickup_deadline">Reservation Time</label>
                <select id="pickup_deadline" name="pickup_deadline" required>
                    <option value="">Select Time</option>
        <option value="07:00 AM">07:00 AM</option>
        <option value="07:30 AM">07:30 AM</option>
        <option value="08:00 AM">08:00 AM</option>
        <option value="08:30 AM">08:30 AM</option>
        <option value="09:00 AM">09:00 AM</option>
        <option value="09:30 AM">09:30 AM</option>
        <option value="10:00 AM">10:00 AM</option>
        <option value="10:30 AM">10:30 AM</option>
        <option value="11:00 AM">11:00 AM</option>
        <option value="11:30 AM">11:30 AM</option>
        <option value="12:00 PM">12:00 PM</option>
        <option value="12:30 PM">12:30 PM</option>
        <option value="01:00 PM">01:00 PM</option>
        <option value="01:30 PM">01:30 PM</option>
        <option value="02:00 PM">02:00 PM</option>
        <option value="02:30 PM">02:30 PM</option>
        <option value="03:00 PM">03:00 PM</option>
        <option value="03:30 PM">03:30 PM</option>
        <option value="04:00 PM">04:00 PM</option>
        <option value="04:30 PM">04:30 PM</option>
        <option value="05:00 PM">05:00 PM</option>
        <option value="05:30 PM">05:30 PM</option>
        <option value="06:00 PM">06:00 PM</option>
        <option value="06:30 PM">06:30 PM</option>
        <option value="07:00 PM">07:00 PM</option>
        <option value="07:30 PM">07:30 PM</option>
        <option value="08:00 PM">08:00 PM</option>
        <option value="08:30 PM">08:30 PM</option>
        <option value="09:00 PM">09:00 PM</option>
        <option value="09:30 PM">09:30 PM</option>
        <option value="10:00 PM">10:00 PM</option>
                    <!-- Add more times as needed -->
                </select>
            </div>

            <div id="delivery-fields" style="display: none;">
    <div class="form-group">
        <label for="drop_point">Drop Point</label>
        <select id="drop_point" name="drop_point">
            <option value="" disabled selected>Select a drop point</option>
            <option value="Main Gate">Main Gate</option>
            <option value="Motorcycle Parking (DK Foyer)">Motorcycle Parking (DK Foyer)</option>
            <option value="Library (Perpustakaan Hamzah Sendut)">Library (Perpustakaan Hamzah Sendut)</option>
            <option value="Lecture Hall Complex (DK)">Lecture Hall Complex (DK)</option>
            <option value="Cafeteria (Restu)">Cafeteria (Restu)</option>
            <option value="Hostel (Desasiswa Bakti)">Hostel (Desasiswa Bakti)</option>
            <option value="Hostel (Desasiswa Restu)">Hostel (Desasiswa Restu)</option>
            <option value="Hostel (Desasiswa Indah Kembara)">Hostel (Desasiswa Indah Kembara)</option>
            <option value="Sports Complex">Sports Complex</option>
            <option value="School of Computer Sciences">School of Computer Sciences</option>
            <option value="School of Engineering">School of Engineering</option>
            <option value="Chancellory (Canselori)">Chancellory (Canselori)</option>
        </select>
    </div>

    <div class="form-group">
        <label for="address">Delivery Address</label>
        <input type="text" id="address" name="address" placeholder="Enter additional details if needed (optional)">
    </div>

    <div class="form-group">
        <label for="volunteer_id">Volunteer</label>
        <select name="volunteer_id" id="volunteer_id">
            <option value="">Select Volunteer</option>
            <?php while ($volunteer = $volunteers->fetch_assoc()) : ?>
                <option value="<?= $volunteer['volunteer_id'] ?>"><?= htmlspecialchars($volunteer['fullname']) ?></option>
            <?php endwhile; ?>
        </select>
    </div>
</div>


            <button type="submit">Reserve Now</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2025 Unibite. All rights reserved.</p>
    </footer>
    <script>
        function toggleDeliveryFields(method) {
            const deliveryFields = document.getElementById('delivery-fields');
            if (method === 'delivery') {
                deliveryFields.style.display = 'block';
            } else {
                deliveryFields.style.display = 'none';
            }
        }
    </script>
</body>
</html>
