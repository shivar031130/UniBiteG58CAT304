<?php
$servername = "localhost"; // Localhost for phpMyAdmin
$username = "root";        // Default username for phpMyAdmin
$password = "";            // Default password for phpMyAdmin (empty for XAMPP/WAMP)
$dbname = "unibite";       // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
