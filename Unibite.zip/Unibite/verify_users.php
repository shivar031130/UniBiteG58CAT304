<?php
session_start();
require 'db_connection.php';

// Ensure only admins can access this page
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch the admin details from the database to confirm the admin's status
$admin_id = $_SESSION['admin_id'];
$sql = "SELECT * FROM admin WHERE admin_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // If no admin record is found, redirect to login
    header("Location: admin_login.php");
    exit();
}

// Handle user verification
if (isset($_POST['verify_user_id'])) {
    $user_id = $_POST['verify_user_id'];
    $sql = "UPDATE users SET is_verified = 1 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $success_message = "User successfully verified!";
    } else {
        $error_message = "Failed to verify user. Please try again.";
    }
}

// Fetch all users
$sql = "SELECT id, fullname, email, profile_picture, matric_id, is_verified FROM users ORDER BY is_verified, fullname ASC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Verify Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 50px;
        }

        .profile-photo {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }

        .verified {
            color: green;
            font-weight: bold;
        }

        .not-verified {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Admin - Verify Users</h1>

        <!-- Success or Error Messages -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?= $success_message; ?></div>
        <?php elseif (isset($error_message)): ?>
            <div class="alert alert-danger"><?= $error_message; ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Profile Photo</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Matric ID</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($user = $result->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <img 
                                src="<?= $user['profile_picture'] ? 'uploads/' . $user['profile_picture'] : 'https://via.placeholder.com/50' ?>" 
                                alt="Profile" 
                                class="profile-photo">
                        </td>
                        <td><?= htmlspecialchars($user['fullname']); ?></td>
                        <td><?= htmlspecialchars($user['email']); ?></td>
                        <td><?= htmlspecialchars($user['matric_id']); ?></td>
                        <td>
                            <?php if ($user['is_verified'] == 1): ?>
                                <span class="verified">Verified</span>
                            <?php else: ?>
                                <span class="not-verified">Not Verified</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($user['is_verified'] == 0): ?>
                                <form method="POST" action="verify_users.php" style="display: inline;">
                                    <input type="hidden" name="verify_user_id" value="<?= $user['id']; ?>">
                                    <button type="submit" class="btn btn-success btn-sm">Verify</button>
                                </form>
                            <?php else: ?>
                                <button class="btn btn-secondary btn-sm" disabled>Verified</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
