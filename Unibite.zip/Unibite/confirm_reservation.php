<?php
session_start();
include('db_connection.php');

// Get reservation ID from URL
$reservation_id = $_GET['reservation_id'] ?? null;
if ($reservation_id) {
    // Update the reservation status to 'Completed'
    $update_query = "UPDATE reservations SET status = 'Completed' WHERE reservation_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("i", $reservation_id);
    if ($update_stmt->execute()) {
        echo "<p>Your reservation has been confirmed and updated to 'Completed'. Thank you!</p>";
    } else {
        echo "<p>Sorry, there was an error confirming your reservation. Please try again.</p>";
    }
} else {
    echo "<p>Invalid confirmation link.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Reservation</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Reservation Confirmation</h1>
    </header>
    <main>
        <div class="confirmation">
            <p><a href="index.php">Back to Home</a></p>
        </div>
    </main>
    <footer>
        <p>&copy; 2025 Unibite. All rights reserved.</p>
    </footer>
</body>
</html>
