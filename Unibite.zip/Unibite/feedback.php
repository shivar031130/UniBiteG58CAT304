<?php
// Include database connection
include('db_connection.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user ID from the session
$id = $_SESSION['id'];

// Handle feedback form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submitFeedback'])) {
    // Get form input
    $reservation_id = $_POST['reservationId']; // Reservation ID from the dropdown
    $rating = filter_var($_POST['rating'], FILTER_VALIDATE_INT);
    $comments = mysqli_real_escape_string($conn, trim($_POST['comments']));

    // Validate input
    if ($reservation_id && $rating && !empty($comments)) {
        // Check if feedback for this reservation already exists
        $check_feedback_query = "SELECT * FROM feedback WHERE reservation_id = ? AND id = ?";
        $stmt = $conn->prepare($check_feedback_query);
        $stmt->bind_param("ii", $reservation_id, $id);
        $stmt->execute();
        $feedback_check_result = $stmt->get_result();

        if ($feedback_check_result->num_rows > 0) {
            $error_message = "Feedback for this reservation already exists. You cannot submit duplicate feedback.";
        } else {
            // Insert feedback into the database
            $feedback_query = "INSERT INTO feedback (reservation_id, id, rating, comments, feedback_date) 
                               VALUES (?, ?, ?, ?, NOW())";
            $stmt = $conn->prepare($feedback_query);
            $stmt->bind_param("iiis", $reservation_id, $id, $rating, $comments);

            if ($stmt->execute()) {
                $success_message = "Feedback submitted successfully!";
            } else {
                $error_message = "Failed to submit feedback. Please try again.";
            }
        }
    } else {
        $error_message = "Please provide all required details.";
    }
}


// Fetch completed reservations for the logged-in user
$reservation_query = "
    SELECT reservation_id, reservation_date, delivery_address
    FROM reservations
    WHERE id = ? AND status = 'completed'
    ORDER BY reservation_date DESC
";
$stmt = $conn->prepare($reservation_query);
$stmt->bind_param("i", $id);
$stmt->execute();
$reservation_result = $stmt->get_result();

// Fetch feedback history for the logged-in user
$feedback_history_query = "
    SELECT 
        f.reservation_id, 
        f.rating, 
        f.comments, 
        f.feedback_date, 
        r.reservation_date, 
        r.delivery_address, 
        u.nickname AS donor_nickname, 
        d.meal_name
    FROM feedback f
    INNER JOIN reservations r ON f.reservation_id = r.reservation_id
    INNER JOIN donations d ON r.donation_id = d.donation_id
    INNER JOIN users u ON d.id = u.id
    WHERE f.id = ?
    ORDER BY f.feedback_date DESC
";

$stmt = $conn->prepare($feedback_history_query);
$stmt->bind_param("i", $id);
$stmt->execute();
$feedback_history_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback | UniBite</title>
   <style>/* General Reset */
body, h1, h2, h3, p, ul, li, a, input, select, button, textarea, table {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    background-color: #fef9f4;
    color: #333;
    line-height: 1.6;
    font-size: 16px;
}

/* Header Styling */
header {
    background: linear-gradient(90deg, #ff6e40, #ffa726);
    color: #fff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
}

header .logo {
    display: flex;
    align-items: center;
}

header .logo img {
    width: 50px;
    margin-right: 10px;
}

header .logo h1 {
    font-size: 24px;
    font-weight: 700;
}

header nav ul {
    list-style: none;
    display: flex;
}

header nav ul li {
    margin-left: 20px;
}

header nav ul li a {
    color: #fff;
    text-decoration: none;
    font-size: 16px;
    padding: 8px 12px;
    border-radius: 4px;
    transition: background 0.3s ease, color 0.3s ease;
}

header nav ul li a:hover {
    background-color: #fff;
    color: #ff6e40;
}

/* Feedback Section */
.feedback-section, .feedback-history {
    max-width: 900px;
    margin: 30px auto;
    padding: 20px;
    background: linear-gradient(145deg, #ffffff, #f3f3f3);
    box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.feedback-section:hover, .feedback-history:hover {
    transform: translateY(-5px);
    box-shadow: 0px 12px 30px rgba(0, 0, 0, 0.2);
}

.feedback-section h2, .feedback-history h2 {
    font-size: 22px;
    font-weight: 600;
    margin-bottom: 20px;
    color: #ff6e40;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 8px;
    color: #333;
}

select, textarea, input[type="text"] {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    outline: none;
    transition: border 0.3s ease, box-shadow 0.3s ease;
}

select:focus, textarea:focus, input[type="text"]:focus {
    border-color: #ff6e40;
    box-shadow: 0 0 8px rgba(255, 110, 64, 0.5);
}

textarea {
    resize: none;
}

button.submit-btn {
    background: linear-gradient(90deg, #ff6e40, #ffa726);
    color: #fff;
    border: none;
    padding: 12px 20px;
    border-radius: 4px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
}

button.submit-btn:hover {
    background: linear-gradient(90deg, #ff5722, #ff9800);
    transform: translateY(-2px);
    box-shadow: 0px 8px 20px rgba(255, 110, 64, 0.5);
}

/* Success and Error Messages */
p[style="color: green;"] {
    background-color: #e8f8e8;
    color: #28a745;
    padding: 10px 15px;
    border-left: 4px solid #28a745;
    border-radius: 4px;
    margin-bottom: 20px;
}

p[style="color: red;"] {
    background-color: #fdecea;
    color: #dc3545;
    padding: 10px 15px;
    border-left: 4px solid #dc3545;
    border-radius: 4px;
    margin-bottom: 20px;
}

/* Feedback History Table */
.feedback-history table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    border-radius: 8px;
    font-weight: bold;
}

.feedback-history table th, .feedback-history table td {
    padding: 12px 15px;
    text-align: left;
    border: 1px solid #ddd;
    font-size: 14px;
    font-weight: bold;
    color: #333;
    background-color: #fff;
    transition: background-color 0.3s ease;
}

.feedback-history table th {
    background: linear-gradient(90deg, #ff6e40, #ffa726);
    color: #fff;
    font-weight: 600;
}

.feedback-history table tr:nth-child(even) td {
    background-color: #f9f9f9;
}

.feedback-history table tr:hover td {
    background-color: #ffe5d4;
}
 /* Buttons */
 button, .home-button {
            background: linear-gradient(90deg, #ff6e40, #ffa726);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        button:hover, .home-button:hover {
            background: linear-gradient(90deg, #ff5722, #ff9800);
            transform: translateY(-2px);
            box-shadow: 0px 8px 20px rgba(255, 110, 64, 0.5);
        }
/* Footer */
footer {
    text-align: center;
    padding: 20px 0;
    background: linear-gradient(90deg, #ff6e40, #ffa726);
    color: #fff;
    margin-top: 30px;
    font-size: 14px;
}
</style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">
            <img src="assets/logo1.png" alt="UniBite Logo">
            <h1>UniBite</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php" class="nav-link">Home</a></li>
                <li><a href="donate.php" class="nav-link">Donate</a></li>
                <li><a href="services.html" class="nav-link">Services</a></li>
                <li><a href="contact.html" class="nav-link">Contact</a></li>
                <li><a href="aboutus.html" class="nav-link">About Us</a></li>
                <li><a href="logout.php" class="nav-link login">Logout</a></li>
            </ul>
        </nav>
    </header>

    <!-- Feedback Section -->
    <section class="feedback-section">
        <h2>Submit Feedback</h2>

        <!-- Display success or error messages -->
        <?php if (isset($success_message)): ?>
            <p style="color: green;"><?php echo $success_message; ?></p>
        <?php elseif (isset($error_message)): ?>
            <p style="color: red;"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <!-- Feedback Form -->
        <?php if ($reservation_result->num_rows > 0): ?>
            <form method="POST" action="feedback.php">
                <div class="form-group">
                    <label for="reservationId">Select Reservation:</label>
                    <select id="reservationId" name="reservationId" required>
                        <option value="">-- Select a Reservation --</option>
                        <?php while ($row = $reservation_result->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($row['reservation_id']); ?>">
                                <?= htmlspecialchars("Reservation on " . $row['reservation_date'] . " - " . $row['delivery_address']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="rating">Rating:</label>
                    <select id="rating" name="rating" required>
                        <option value="">Select Rating</option>
                        <option value="1">1 - Poor</option>
                        <option value="2">2 - Fair</option>
                        <option value="3">3 - Good</option>
                        <option value="4">4 - Very Good</option>
                        <option value="5">5 - Excellent</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="comments">Comments:</label>
                    <textarea id="comments" name="comments" rows="4" required placeholder="Leave your comments here"></textarea>
                </div>

                <button type="submit" name="submitFeedback" class="submit-btn">Submit Feedback</button>
            </form>
        <?php else: ?>
            <p>No completed reservations found. You cannot submit feedback at this time.</p>
        <?php endif; ?>
    </section>

    <!-- Feedback History Section -->
    <section class="feedback-history">
        <h2>Feedback History</h2>
        <?php if ($feedback_history_result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Reservation ID</th>
                        <th>Reservation Date</th>
                        <th>Delivery Address</th>
                        <th>Donor Nickname</th>
                        <th>Meal Name</th>
                        <th>Rating</th>
                        <th>Comments</th>
                        <th>Feedback Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $feedback_history_result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['reservation_id']); ?></td>
                            <td><?= htmlspecialchars($row['reservation_date']); ?></td>
                            <td><?= htmlspecialchars($row['delivery_address']); ?></td>
                            <td><?= htmlspecialchars($row['donor_nickname']); ?></td>
                            <td><?= htmlspecialchars($row['meal_name']); ?></td>
                            <td><?= htmlspecialchars($row['rating']); ?></td>
                            <td><?= htmlspecialchars($row['comments']); ?></td>
                            <td><?= htmlspecialchars($row['feedback_date']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No feedback history found.</p>
        <?php endif; ?>
        <!-- Home Button -->
        <a href="dashboard.php">
                <button class="home-button">Back to Dashboard</button>
            </a>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 UniBite. All rights reserved.</p>
    </footer>
</body>
</html>
