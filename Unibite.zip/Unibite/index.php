<?php
// Start session
session_start();

// Include database connection (adjust based on your file structure)
include('db_connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UniBite - Campus Food Bank</title>
  <!-- Font Awesome for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    /* General Styling */
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: url('https://images.unsplash.com/photo-1560807707-8cc77767d783?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      background-color: rgba(0, 0, 0, 0.8);
    }

    header .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    header .logo-img {
      width: 50px; /* Set the width of the logo */
      height: auto; /* Maintain the aspect ratio */
    }

    header h1 {
      font-size: 1.5rem;
      color: #ff7637;
      margin: 0;
    }

    header nav ul {
      display: flex;
      list-style: none;
    }

    header nav ul li {
      margin: 0 10px;
    }

    header nav ul li a {
      color: #fff;
      text-decoration: none;
      font-size: 1.1rem;
      transition: all 0.3s ease;
    }

    header nav ul li a:hover {
      color: #ff5900;
      transform: scale(1.1);
    }

    header nav ul li a.login {
      background: #ff5500;
      color: #333;
      padding: 5px 15px;
      border-radius: 20px;
      font-weight: bold;
    }

    header nav ul li a.login:hover {
      background: #FFA500;
    }

    /* Video Section */
    .video-section {
      position: relative;
    }

    .video-placeholder video {
      width: 100%;
      height: auto;
    }

    /* Welcome Section */
    .welcome-section {
      text-align: center;
      padding: 50px 20px;
      background: rgba(0, 0, 0, 0.7);
    }

    .welcome-section h2 {
      font-size: 5.5rem;
      font-weight: bold;
      margin-bottom: 20px;
    }

    .welcome-section h2 .highlight {
      color: #ff6200;
    }

    .action-buttons {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      margin-top: 30px;
    }

    .action-card {
      text-align: center;
      margin: 15px;
      background: linear-gradient(105deg,rgb(255, 111, 0),rgb(255, 232, 222));
      color: #333;
      text-decoration: none;
      padding: 20px;
      border-radius: 10px;
      width: 200px;
      box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .action-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
    }

    .action-card i {
      font-size: 3rem;
      margin-bottom: 15px;
      color: #333;
    }

    .action-card p {
      font-size: 2rem;
      font-weight: bold;
    }

    /* Footer */
    footer {
      text-align: center;
      background-color: rgba(0, 0, 0, 0.9);
      color: #fff;
      padding: 20px;
      margin-top: 20px;
    }

    footer p {
      margin: 10px 0;
    }

    footer .social-icons a {
      color: #ff5100;
      margin: 0 10px;
      font-size: 1.5rem;
      text-decoration: none;
      transition: all 0.3s ease;
    }

    footer .social-icons a:hover {
      color: #FFA500;
    }

    /* Animations */
    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    @keyframes slideUp {
      from {
        transform: translateY(50px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .welcome-section h2, .action-buttons {
      animation: fadeIn 2s ease-in-out;
    }

    .action-card {
      animation: slideUp 1.5s ease-in-out;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      header {
        flex-direction: column;
      }

      header .logo {
        margin-bottom: 10px;
      }

      .action-buttons {
        flex-direction: column;
      }

      .action-card {
        width: 100%;
        margin: 10px 0;
      }
    }
  </style>
</head>
<body>

  <header>
    <div class="logo">
      <img src="assets/logo1.png" alt="UniBite Logo" class="logo-img">
      <h1>UniBite</h1>
    </div>
    <nav>
      <ul>
        <li><a href="index.php" class="nav-link">Home</a></li>
        <li><a href="donate.php" class="nav-link">Donate</a></li>
        <li><a href="services.html" class="nav-link">Services</a></li>
        <li><a href="contactus.html" class="nav-link">Contact</a></li>
        <li><a href="aboutus.html" class="nav-link">About Us</a></li>
        <li><a href="signup_options.php" class="nav-link login">Login</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="video-section">
      <div class="video-placeholder">
        <video autoplay muted loop playsinline>
          <source src="assets/LOGO.mp4" type="video/mp4">
          Your browser does not support the video tag.
        </video>
      </div>
    </section>

    <section class="welcome-section">
      <h2>Welcome to, <span class="highlight">UniBite</span></h2>
      <div class="action-buttons">
        <a href="inventory.php" class="action-card">
          <i class="fas fa-warehouse"></i>
          <p>View Available Food</p>
        </a>
        <a href="donate.php" class="action-card">
          <i class="fas fa-hands-helping"></i>
          <p>Donate Meal</p>
        </a>
        <a href="signup_volunteer.php" class="action-card">
          <i class="fas fa-users"></i>
          <p>Register as Delivery Volunteer</p>
        </a>
        <a href="dashboard.php" class="action-card">
          <i class="fas fa-user-circle"></i>
          <p>User Dashboard</p>
        </a>
      </div>
    </section>
  </main>

  <footer>
    <p>© 2025 UniBite. All rights reserved. | Campus Food Bank Initiative</p>
    <div class="social-icons">
      <a href="#"><i class="fab fa-facebook"></i></a>
      <a href="#"><i class="fab fa-twitter"></i></a>
      <a href="#"><i class="fab fa-instagram"></i></a>
    </div>
  </footer>

</body>
</html>
