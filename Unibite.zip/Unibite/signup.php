<?php
// Include database connection file
include 'db_connection.php';

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = trim($_POST['fullname']);
    $nickname = trim($_POST['nickname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $matric_id = trim($_POST['matric_id']);
    $user_type = 'user';

   // Profile picture upload
$profile_picture = $_FILES['profile_picture'];
$profile_picture_name = '';
if ($profile_picture['error'] === 0) {
    $profile_picture_name = uniqid() . '_' . basename($profile_picture['name']);
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Create upload directory if it doesn't exist
    }
    move_uploaded_file($profile_picture['tmp_name'], $upload_dir . $profile_picture_name);
}

    // Validate input fields
    if (empty($fullname) || empty($nickname) || empty($email) || empty($password) || empty($matric_id)) {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user into the database
        $sql = "INSERT INTO users (fullname, nickname, email, password, matric_id, user_type, profile_picture) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sssssss', $fullname, $nickname, $email, $hashed_password, $matric_id, $user_type, $profile_picture_name);

        if ($stmt->execute()) {
            $success = 'Registration successful! You can now log in.';
        } else {
            $error = 'Error: ' . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up as User - UniBite</title>
    <style>
        /* Styling from the latest request */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #fdf3f0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header .logo {
            display: flex;
            align-items: center;
        }

        header .logo img {
            width: 60px;
            margin-right: 10px;
        }

        header nav ul {
            display: flex;
            list-style: none;
        }

        header nav ul li {
            margin: 0 10px;
        }

        header nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        header nav ul li a:hover {
            color: #000;
        }

        header nav ul li .login {
            background-color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            color: #ff7247;
        }

        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin-top: 30px;
        }

        .form-box {
            width: 100%;
            max-width: 500px;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.93);
        }

        .form-box h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 2rem;
            color: #ff7247;
        }

        .form-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1rem;
        }

        .form-box button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(90deg, #ff5722, #ff9800);
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-box button:hover {
            background-color: #e05c3b;
        }

        .form-box p {
            text-align: center;
            margin-top: 20px;
            font-size: 1rem;
        }

        .form-box .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }

        .form-box .success {
            color: green;
            text-align: center;
            margin-bottom: 15px;
        }
        footer {
        text-align: center;
        padding: 20px 0;
        background: linear-gradient(90deg, #ff6e40, #ffa726);
        color: #fff;
        margin-top: 30px;
        font-size: 14px;
    }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="assets/logo1.png" alt="UniBite Logo">
            <h1>UniBite</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="donate.php">Donate</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="aboutus.php">About Us</a></li>
                <li><a href="login.php" class="login">Login</a></li>
            </ul>
        </nav>
    </header>

    <div class="form-container">
        <div class="form-box">
            <h2>Sign Up as User</h2>
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data">
                <input type="text" name="fullname" placeholder="Full Name" required>
                <input type="text" name="nickname" placeholder="Nickname" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="text" name="matric_id" placeholder="Matric ID/IC No" required>
                <label for="profile_picture">Upload Profile Picture:</label>
                <input type="file" name="profile_picture" id="profile_picture" required>
                <button type="submit">Sign Up</button>
            </form>
        </div>
    </div>
    <footer>
        <p>&copy; 2025 UniBite. All Rights Reserved.</p>
    </footer>
</body>
</html>
